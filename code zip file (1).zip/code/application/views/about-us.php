
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Altoona - Interior Creator HTML Template | Contact Us</title>
<!-- Stylesheets -->
<link href="<?php echo base_url();?>application/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url();?>application/css/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>application/css/responsive.css" rel="stylesheet"> 
<!--Color Switcher Mockup-->

<link href="<?php echo base_url();?>application/css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->

<link id="theme-color-file" href="<?php echo base_url();?>application/css/color-themes/default-theme.css" rel="stylesheet">


<link rel="shortcut icon" href="<?php echo base_url();?>application/images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>application/images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">


    <?php include_once("header.php"); ?>

    <!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo base_url();?>application/images/background/24.jpg);">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>About Us</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo base_url();?>application/index.php"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span> About Us</li>
                </ul>
            </div>
        </div>
    </section>


    <section class="about-section">
        <div class="auto-container">
            <div class="row">
                <div class="content-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                        <div class="content-box abt-text">
                            <div class="sec-title">
                                <h2 data-animation-child="" class="title-fill" data-animation="title-fill-anim" data-text="About Company">Who we are?</h2>
                            </div>
                            <p><strong>“The Technology based, Promising and Authentic construction and Interior designing service company”</strong></p>
                          <p>Unico Designs Infratech Private Limited was born to fulfill the range of your home needs like planning and architecture service, house/villa construction, interior design and execution, and home renovation or remodeling.</p>
                          <p>We are a team with zeal, motivation, creativity, professionalism, and friendliness. We bring your visionary house into reality with our trendsetting ideas. We are renowned for the finest finishing where we choose premium materials and pay attention to minute details to bring out the state of the artwork.</p>
                          <p>Our solid vision and uncompromising mission made us today one of the demanding and fast-growing construction and interior designing company in Hyderabad. As we are ISO certified company, one can be guaranteed of quality work.</p>
                          <p>Amidst COVID-19, we have adopted stringent measures at every step to assure a no-contact safety environment starting from our office premises to every area of your house. You can feel safe to visit us for the discussion and a green zone to move into your dream house.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="about-section">
        <div class="auto-container">
            <div class="row">
                <!-- Image Column -->
                <div class="col-lg-6 col-md-12 col-sm-12">
                <img src="<?php echo base_url();?>application/images/about/construction.jpg" alt="">
                </div>

                <!-- Content Column -->
                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                        <div class="content-box abt-text">
                            <div class="sec-title">
                                <h2 data-animation-child="" class="title-fill" data-animation="title-fill-anim" data-text="About Company">Construction</h2>
                            </div>
                            <h5>House/Villa Construction</h5>
                            <p><strong>“A transparent and outstanding construction service with 5 years of warranty”</strong></p>
                           <p>Buildhood Infratech feels proud for completing 150+ projects in its journey. We are urged to provide modernized, quality, professional, and transparent service to everyone. Our experts are specialized in turning your dream house into reality. We carefully pick and finalize the best in everything. We are recognized for our world-class finishing that made even a simple house look stylish.</p>
                           <p>Every house owner is valued at Buildhood Infratech. We are satisfied and relaxed when our house owner’s expectations are met. Hence, we boldly offer service with 5 years of warranty.</p>
                           <p>Through on-time completion of projects, we have earned the trust in the market. Our professional and friendly customer service made us stand out distinctively from the crowd.</p>
                         
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="about-section">
        <div class="auto-container">
            <div class="row">
                <!-- Image Column -->
           

                <!-- Content Column -->
                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                        <div class="content-box abt-text">
                            <div class="sec-title">
                                <h2 data-animation-child="" class="title-fill" data-animation="title-fill-anim" data-text="About Company">Interiors</h2>
                            </div>
                            <h5>Interior Design and Execution</h5>
                            <p><strong>“Our interior design will never allow your eye to settle in one place”</strong></p>
                          <p>We strongly believe that interior designing speaks who you are, with whom do you live, the collections you love, and a lot more about you. Holding a vast knowledge of designing the interiors, we through the light into your house with magnificent designs that boost peace, calmness, and a lot more positivity that are good for your soul.</p>
                          <p>We design based on the concepts, your style, and color taste. We make the best use of the available space. Our interior designs make you feel like living in the palace with all the luxury that comes in handy at an affordable price.</p>
                         <p>During this crisis of COVID-19, all the materials are fumigated and our staff are equipped with a face mask and sanitized regularly.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 col-sm-12">
                <img src="<?php echo base_url();?>application/images/about/interiors.jpg" alt="">
                </div>


            </div>
        </div>
    </section>

    <section class="about-section">
        <div class="auto-container">
            <div class="row">
               
          

            <div class="col-lg-6 col-md-12 col-sm-12">
                <img src="<?php echo base_url();?>application/images/about/renovations.jpg" alt="">
                </div>


                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                        <div class="content-box abt-text">
                            <div class="sec-title">
                                <h2 data-animation-child="" class="title-fill" data-animation="title-fill-anim" data-text="About Company">Renovations</h2>
                            </div>
                            <h5>Home Renovation or Remodeling</h5>
                            <p><strong>“Far more than renovation, we transform your space and give it a new look”</strong></p>
                        <p>We are well-known in the market for our professional and friendly renovation service in Hyderabad. We make renovation or remodeling much easier than ever. We have completion of 120+ records of house renovation in the count.</p>
                        <p>We are specialized in curating the unique and creative ideas that transform your house/villa completely into a fresh, modish, and rejuvenating space. We strictly utilize quality materials that give a top-notch finishing.</p>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>

    <section class="about-section">
        <div class="auto-container">
            <div class="row">
               
                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                        <div class="content-box abt-text">
                            <div class="sec-title">
                                <h2 data-animation-child="" class="title-fill" data-animation="title-fill-anim" data-text="About Company">Planning Architecture</h2>
                            </div>
                            <h5>Planning and Architecture Service</h5>
                            <p><strong>“We design for the present with the understanding of the past and prediction of the future”</strong></p>
                     <p>We are good listeners, we listen and jot down all your requirements. Our architects are professionals in carving designs by turning the concepts into images and plans. We create the overall look of the building and structure design far more than its appearance. Creativity is something a core area we focus on in the designing.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 col-sm-12">
                <img src="<?php echo base_url();?>application/images/about/planning.jpg" alt="">
                </div>


            </div>
        </div>
    </section>

    <section class="about-section">
        <div class="auto-container">
            <div class="row">
                <div class="content-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                        <div class="content-box abt-text">
                            <div class="sec-title">
                                <h2 data-animation-child="" class="title-fill" data-animation="title-fill-anim" data-text="About Company">Vision</h2>
                            </div>
                            <p><strong>“Focused on delivering quality, modish, affordable price, and professional service”</strong></p>
                         <p>Our vision is to build the house for pleasant living. Any good things we construct end up building us. We are urged to render quality and the finest finishing touch for the long-lasting durability of the house.</p>
                         <h3>Quality</h3>
                        <p>What goes into the construction of the house is vital for the company. When it comes to material and design we never make any other choice other than going with the quality. Our Quality work remains forever and ever as it is our habit.</p>
                        <h3>Unique and modern</h3>
                        <p>To deploy robust strategies in everything we do that make us look unique and modern in the competitive world. We strive to make every house construction value-added and unique in style. We solve complex problems easily and make them look simple.</p>
                        <h3>Affordable price</h3>
                        <p>To raise the standard of living in our country, we are aimed to construct a luxurious house at an affordable price even for middle-class people.</p>
                        <h3>Professional customer service</h3>
                        <p>We keep ourselves reachable 24/7 for any queries to solve. For every customer, we offer a construction service that comes with 5 years of warranty. We are satisfied when our customers are happy and peaceful.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="about-section">
        <div class="auto-container">
            <div class="row">
                <div class="content-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                        <div class="content-box abt-text">
                            <div class="sec-title">
                                <h2 data-animation-child="" class="title-fill" data-animation="title-fill-anim" data-text="About Company">Mission</h2>
                            </div>
                           <p>We toil to achieve the vision by hard work and friendly service. Buildhood Infratech houses a bunch of talents that bring value and change to the organization. Our experts are go-getters and never stop for anything until they achieve the goal. We go the extra mile and make things happen.</p>
                           <h3>Friendly working environment</h3>
                           <p>Our company is a great platform to learn and grow in a career. We create a friendly and inspired workplace for them to invent and implement unique ideas into the construction and design areas.</p>
                           <h3>Updated with latest technology and ideas</h3>
                           <p>We are equipped with the latest technology that makes work easy and faster. Our team is updated with the designs and construction ideas that are trending worldwide. Researching and adopting the latest things has become our daily activity.</p>
                           <h3>Time Management</h3>
                           <p>As promised to our customers, we ensure the project is completed on time as per the design with the quality intact. On-time project completion builds and enhances the trust between us and customers.</p>
                           <h3>Regular check</h3>
                           <p>Our dedicated team regularly checks the construction work at every stage to make sure everything is going as per the finalized design. The regular check assure that we are moving in the right direction of project completion.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <br><br><br><br><br>



    <?php include_once("footer.php"); ?>


</div>



<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="<?php echo base_url();?>application/js/jquery.js"></script> 
<script src="<?php echo base_url();?>application/js/popper.min.js"></script>
<script src="<?php echo base_url();?>application/js/bootstrap.min.js"></script>

<script src="<?php echo base_url();?>application/js/jquery.fancybox.js"></script>
<script src="<?php echo base_url();?>application/js/owl.js"></script>
<script src="<?php echo base_url();?>application/js/wow.js"></script>
<script src="<?php echo base_url();?>application/js/appear.js"></script>
<script src="<?php echo base_url();?>application/js/isotope.js"></script>
<script src="<?php echo base_url();?>application/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo base_url();?>application/js/jquery-ui.js"></script>
<script src="<?php echo base_url();?>application/js/mixitup.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="<?php echo base_url();?>application/js/map-script.js"></script>
<script src="<?php echo base_url();?>application/js/script.js"></script>
<!-- Color Setting -->
<script src="<?php echo base_url();?>application/js/color-settings.js"></script>
</body>
</html>