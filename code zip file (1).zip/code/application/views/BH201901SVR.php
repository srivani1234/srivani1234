
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Altoona - Interior Creator HTML Template | Contact Us</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">   
<!--Color Switcher Mockup-->
<link href="css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">


    <?php include_once("header.php"); ?>

    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/24.jpg);">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>Project code : BH201901SVR</h1>
                </div>
            
            </div>
        </div>
    </section>


<section class="services-section style-seven" style="background-image: url(images/background/1.jpg);">
        <div class="auto-container">    
           
            <div class="row clearfix">
			
			<div class="col-lg-1 col-md-6 col-sm-12"></div>
			
    <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/icons/p-1.png">
      <h2>Chandapura</h2>
	  <p>Location</p>
    </div>
    <div class="flip-box-back flip-box-front-2">
      <img src="images/icons/p-1.png">
      <h2>Chandapura</h2>
	  <p>Location</p>
    </div>
  </div>
</div>
 </div>
 
     <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/icons/p-2.png">
      <h2>1700 sq.ft.</h2>
	  <p>Area</p>
    </div>
    <div class="flip-box-back flip-box-front-2">
       <img src="images/icons/p-2.png">
      <h2>1700 sq.ft.</h2>
	  <p>Area</p>
    </div>
  </div>
</div>
 </div>
 
      <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
     <img src="images/icons/p-3.png">
      <h2>G + 2</h2>
	  <p>Floors</p>
    </div>
    <div class="flip-box-back flip-box-front-2">
      <img src="images/icons/p-3.png">
     <h2>G + 2</h2>
	  <p>Floors</p>
    </div>
  </div>
</div>
 </div>
 
 
       <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/icons/p-4.png">
      <h2>Platinum Package</h2>
	  <p>Package</p>
    </div>
    <div class="flip-box-back flip-box-front-2">
      <img src="images/icons/p-4.png">
       <h2>Platinum Package</h2>
	  <p>Package</p>
    </div>
  </div>
</div>
 </div>
 
       <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/icons/p-5.png">
      <h2>Completed</h2>
	  <p>Status</p>
    </div>
    <div class="flip-box-back flip-box-front-2">
      <img src="images/icons/p-5.png">
      <h2>Completed</h2>
	  <p>Status</p>
    </div>
  </div>
</div>
 </div>
 
        <div class="col-lg-1 col-md-6 col-sm-12"></div>

  </div>
        </div>
        <br>
    </section>
	
	

 <section class="filters packages packages-details">
	 <div class="container">
	 <div class="sec-title text-left">
        <h2>Packages Details</h2>
    </div>
	  <div class="row">
      <div class="col-lg-12">
  <ul class="filters-content">
    <button class="filters__button is-active" data-target="#construction-images">
 Construction Images
    </button>
    <button class="filters__button" data-target="#design-images">
Design Images
    </button>
	
  </ul>

  <div>
 <div data-content class="is-active" id="construction-images">
<div class="items-container row clearfix" style="position: relative; height: 1373.62px;">
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item column-gallery masonry-item all hospitality" style="position: absolute; left: 0px; top: 0px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-1.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-1.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all residential commercial" style="position: absolute; left: 399px; top: 0px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-2.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-2.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all commercial interior-design residential" style="position: absolute; left: 799px; top: 0px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-3.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-3.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all residential" style="position: absolute; left: 0px; top: 420px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-4.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-4.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all residential" style="position: absolute; left: 799px; top: 420px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-5.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-5.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item column-gallery masonry-item all commercial residential" style="position: absolute; left: 399px; top: 490px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-6.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-6.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all interior-design" style="position: absolute; left: 799px; top: 779px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-9.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-9.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>  

                      <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all interior-design" style="position: absolute; left: 399px; top: 850px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-8.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-8.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all interior-design" style="position: absolute; left: 0px; top: 1012px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-7.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-7.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                    
                </div>
</div>

    <div data-content id="design-images">
<div class="items-container row clearfix" style="position: relative; height: 1373.62px;">
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item column-gallery masonry-item all hospitality" style="position: absolute; left: 0px; top: 0px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-1.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-1.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all residential commercial" style="position: absolute; left: 399px; top: 0px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-2.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-2.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all commercial interior-design residential" style="position: absolute; left: 799px; top: 0px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-3.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-3.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all residential" style="position: absolute; left: 0px; top: 420px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-4.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-4.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all residential" style="position: absolute; left: 799px; top: 420px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-5.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-5.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item column-gallery masonry-item all commercial residential" style="position: absolute; left: 399px; top: 490px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-6.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-6.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all interior-design" style="position: absolute; left: 799px; top: 779px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-9.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-9.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>  

                      <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all interior-design" style="position: absolute; left: 399px; top: 850px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-8.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-8.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Default Portfolio Item-->
                    <div class="default-portfolio-item small-column masonry-item all interior-design" style="position: absolute; left: 0px; top: 1012px;">
                        <div class="inner-box">
                            <figure class="image-box"><img src="images/gallery/2-7.jpg" alt=""></figure>
                            <!--Overlay Box-->
                            <div class="overlay-box">
                                <div class="overlay-inner">
                                    <div class="content">
                                        <a href="images/gallery/2-7.jpg" class="lightbox-image link" data-fancybox="images" data-caption="" title=""><span class="icon flaticon-add"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                    
                </div>
    </div>

  </div>
	  </div>
       </div>
	    </div>
    </section>

    
	
	
   
   

 


    
	    <section class="clients-section style-four">
        <div class="auto-container">
		<div class="sec-title text-left">
                <h2>Our Brands</h2>
            </div>
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                </ul>
            </div>
        </div>
    </section>


<br><br>

    <footer class="main-footer style-three">
    <div class="auto-container">
        <div class="widgets-section">
            <div class="row">
                <!--Big Column-->
                <div class="big-column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                    <div class="row">
                        <!--Footer Column-->
                        <div class="footer-column col-xl-7 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget about-widget">
                                <h2 class="widget-title">About Us</h2>
                                <div class="widget-content">
                                    <div class="text">Lorem ipsum is simply free text dolor sit amet, consecte tur notted adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqualonm.</div>
                                 
                                </div>
                            </div>
                        </div>
                        
                        <!--Footer Column-->
                        <div class="footer-column col-xl-5 col-lg-6 col-md-6 col-sm-12">
                             <div class="footer-widget links-widget">
                                <h2 class="widget-title">Quick Links</h2>
                                <div class="widget-content">
                                    <ul class="list">
                                        <li><a href="index.php"> Home </a></li>
                                        <li><a href="about-us.php"> About Us </a></li>
                                        <li><a href="construction.php"> Construction </a></li>
                                        <li><a href="architecture.php"> Architecture </a></li>
                                        <li><a href="projects.php"> Projects </a></li>
                                        <li><a href="contact-us.php"> Contact Us </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>         
                    </div>
                </div>
                
                <!--Big Column-->
                <div class="big-column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                    <div class="row clearfix">
                        <!--Footer Column-->
                        <div class="footer-column col-xl-7 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget gallery-widget">
                                <h2 class="widget-title">Recent Projects</h2>
                                <div class="widget-content">
                                    <div class="outer clearfix">
                                        <figure class="image">
                                            <a href="images/resource/work-thumb-1.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-1.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-2.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-2.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-3.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-3.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-4.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-4.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-5.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-5.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-6.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-6.jpg" alt=""></a>
                                        </figure>
                                    </div>
                                </div>       
                            </div>
                        </div>
                        <div class="footer-column col-xl-5 col-lg-6 col-md-6 col-sm-12">
                             <div class="footer-widget links-widget">
                                <h2 class="widget-title">Contact Us</h2>
                                <div class="widget-content">
                                    <ul class="list-address">
                                        <li><i class="fas fa-map-marker-alt"></i>Hyderabad, Telangana, India.</li>
                                        <li><i class="fas fa-phone-volume"></i><a href="tel:+91 9876543210">+91 9876543210</a></li>
                                        <li><i class="fas fa-envelope"></i><a href="mailto:info@unicodesigns.com">info@unicodesigns.com</a></li>
                                    </ul>
                                    <div class="social-links">
                                        <ul class="social-icon-two">
                                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                                           
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--Footer Bottom-->
    <div class="footer-bottom style-two">
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="inner-container clearfix">
                        <div class="copyright-text">
                            <p> © 2022 Unico Designs. All Right Reserved.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="inner-container clearfix">
                        <div class="copyright-text powered">
                            <p> Powered by <a href="https://royalitpark.com/" target="_blank"> Royal IT Park</a> </p>
                        </div>
                    </div>
                   
                </div>
            </div>
          
        </div>
    </div>
</footer>

</div>

<!-- Color Palate / Color Switcher -->


<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/script.js"></script>
<!-- Color Setting -->
<script src="js/color-settings.js"></script>

   <script>
const tabs = document.querySelectorAll("[data-target]"),
  tabContents = document.querySelectorAll("[data-content]");

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const target = document.querySelector(tab.dataset.target);

    tabContents.forEach((tc) => {
      tc.classList.remove("is-active");
    });
    target.classList.add("is-active");

    tabs.forEach((t) => {
      t.classList.remove("is-active");
    });
    tab.classList.add("is-active");
  });
});


</script>


</body>
</html>