<?php  include_once('common/connection.php') ;?>
<style>
    *{
        padding:0px;
        margin:0px;
        box-sizing:border-box;
        list-style: none;
        text-decoration: none;
    }
    
    .sidebar{
        width:200px;
        height:100%;
        background-color:#d1d1e0;
        color : black;
    }
    .header{
        margin-left:200px;
        width:100%;
        height:10%;
        background-color:#f0f5f5; 
    }
    .container{

        position :relative;
    display:flex;  
        margin-left:0px;
        width:100%;
    }
    .sidebar h2{
text-align:center;
color:black !important;
margin-bottom: 30px;
margin-top:10px;
    } 
    .sidebar ul li{
        margin-bottom:20px;
        padding:20px;
        border-bottom: 1px solid rgba(0,0,0,0.05);
        border-top:ipx solid rgba(225,225,225,0.05);
    }
   /* .tag{

    /* height:50%;
   // width:; 

   } */ 
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="<?php //echo base_url();?>css/style.css"> -->
   <!-- // <title>Document</title> -->
</head>
<body>

    <div class="sidebar">
        <h2>Sidebar</h2>
<ul class="tag"><li><a href="#"><i class="fa-solid fa-person-digging">
</i>Construction</a>
<ul class="class"><li><a href="<?php echo base_url();?>addconstruction">add construction</a></li>
<li  class=''></li>
<li></li></ul></li>
<li>
    <a href="#">Architecture</a>

</li>
<li>
    <a href="#"><i class="fa-solid fa-compass-drafting"></i>Interiors</a>
</li>
<li>
    <a href="#">Renavations</a>
</li>
<!-- <li>
    <a href="#">More</a>

</li> -->
</ul>
    
     <div class="container p-0 mt-0">
 <div class="header">
    Welcome Dashboard
 </div>

    </div>
    </div>
</body>
</html>