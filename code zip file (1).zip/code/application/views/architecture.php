<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Unico Designs</title>

<link href="<?php echo base_url();?>application/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url();?>application/css/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>application/css/responsive.css" rel="stylesheet">   
<link href="<?php echo base_url();?>application/css/color-switcher-design.css" rel="stylesheet">
<link id="theme-color-file" href="<?php echo base_url();?>application/css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="<?php echo base_url();?>application/images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>application/images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
</head>

<body>

<div class="page-wrapper">
  
    <?php include_once("header.php"); ?>

    <section class="banner-section-two" style="background-image: url(<?php echo base_url();?>application/images/main-slider/image.jpg);">
        <div class="auto-container">
            <div class="row outer-column clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="text-column">
                        <div class="content-box">
                            <h1>We are <b>Unico Designs</b></h1>
                            <div class="text">Quality Homes . Transparent Service .
                                Great Value for Money.</div>
                            <div class="link-box">
                                <a href="<?php echo base_url();?>contactus" class="theme-btn btn-style-one">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="form-column">
                      <div class="content-box">
                          <form>
                             <h3>Quick Enquiry</h3>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Name">
  </div>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Phone">
  </div>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Email">
  </div>

  <div class="form-row">
    <div class="form-group col-md-12">
      <select id="inputState" class="form-control">
        <option selected>Select Services</option>
        <option>Construction</option>
        <option>Architecture</option>
        <option>Interior</option>
        <option>Renovations</option>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-12">
      <select id="inputState" class="form-control">
        <option selected>Select your city</option>
        <option>Hyderabad</option>
        <option>Khammam</option>
        <option>Visakhapatnam</option>
      </select>
    </div>
  </div>


  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
       Apply Terms and Condations
      </label>
    </div>
  </div>
  <div class="form-group col-lg-12 col-md-12 col-sm-12">
                                            <button class="theme-btn btn-style-four" type="submit" name="submit-form">Submit Now</button>
                                        </div>  <br>
</form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="about-section">
        <div class="auto-container">
            <div class="row">
             
                <div class="content-column col-lg-8 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                        <div class="content-box">
                            <div class="sec-title">
                                <h2>We Design Personalized Architecture</h2>
                            </div>
                           <p>The outlook of the Buildhood is - “Architecture is not only planning, designing, and constructing the building, it is a part of the culture and art of work”. Everyone at Buildhood strongly believes in this and works firmly at every stage of work. We not only focus on the physical structure of the building but incorporate the culture i.e every emotion, and thought of the people who live in it to set aside an auspicious space for them to live for long.</p>
                           <p>We are recognized as one of the top architecture service providers in the market. Personalization is something exceptional that people appreciate choosing us. Architecture is the discipline within itself and we equally value the Vastu where we push the boundaries of the building in an innovative way for the clear pursuit of the artwork.</p>
                           <p>Whether it is residential and commercial buildings, we are experts in providing landscaping designs, structural designs, and plumbing and electrical designs. Our architecture designs express the value, stimulate, and influence your social life in a greater way. Our systematic investigation of the land helps in producing the extraordinary and perfect architecture of your building.</p>
                           <p>We have in-depth knowledge of the cities and buildings around it. Buildhood is eminent in architecture service, on a deeper level, the buildings we construct are unique, magnificent, add value to the people who live in them and to the city by improving the standard of living.</p>
                        </div>
                    </div>
                </div>

                <div class="image-column col-lg-4 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="image-box"> 
                            <br><br><br>
                        <img src="<?php echo base_url();?>application/images/about/planning-2.jpg" alt="">
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
 
    <section class="services-section style-seven" style="background-image: url(<?php echo base_url();?>application/images/background/1.jpg);">
        <div class="auto-container">    
            <div class="sec-title text-left">
                <h2>What we Design</h2>
            </div>
            <div class="row clearfix">
			
    <div class="col-lg-3 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="<?php echo base_url();?>application/images/architecture/1.png">
      <h2>Residential Architecture</h2>
    </div>
    <div class="flip-box-back flip-box-front-2">
      <img src="<?php echo base_url();?>application/images/architecture/1.png">
      <p>Personalized Designs for affordable Price.</p>
    </div>
  </div>
</div>
 </div>
 
     <div class="col-lg-3 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="<?php echo base_url();?>application/images/architecture/2.png">
      <h2>Commercial Architecture</h2>
    </div>
    <div class="flip-box-back flip-box-front-2">
      <img src="<?php echo base_url();?>application/images/architecture/2.png">
      <p>High standards Designs for affordable Price.</p>
    </div>
  </div>
</div>
 </div>
 
      <div class="col-lg-3 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="<?php echo base_url();?>application/images/architecture/3.png">
      <h2>Landscaping Designs</h2>
    </div>
    <div class="flip-box-back flip-box-front-2">
      <img src="<?php echo base_url();?>application/images/architecture/3.png">
      <p>Personalized and beautiful Landscape designs.</p>
    </div>
  </div>
</div>
 </div>
 
 
       <div class="col-lg-3 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="<?php echo base_url();?>application/images/architecture/4.png">
      <h2>Plumbing & Electrical Designs</h2>
    </div>
    <div class="flip-box-back flip-box-front-2">
      <img src="<?php echo base_url();?>application/images/architecture/4.png">
      <p>Best in class Plumbing and electrical designs.</p>
    </div>
  </div>
</div>
 </div>

  </div>
        </div>
        <br>
    </section>

<section class="gallery-section gallery-section-2">
 <div class="container">
  <div class="sec-title text-left">
    <h2>Packages</h2>
   </div>
   <div class="row">
    <div class="col-lg-12">
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">SECTION</th>
      <th scope="col">STANDARD</th>
      <th scope="col">CLASSIC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>2D FLOOR PLAN</td>
      <td>YES</td>
      <td>YES</td>
    </tr>
    <tr>
      <td>3D FLOOR PLAN</td>
      <td>NO</td>
      <td>NO</td>
    </tr>
    <tr>
      <td>2D ELEVATION</td>
    <td>YES</td>
      <td>YES</td>
    </tr>
	    <tr>
      <td>3D ELEVATION</td>
       <td>YES</td>
      <td>YES</td>
    </tr>
	    <tr>
      <td>NO OF VIEWSNO OF VIEWS</td>
      <td>ONE</td>
      <td>TWO</td>
    </tr>
	    <tr>
      <td>FAÇADE TYPE</td>
      <td>STANDARD</td>
      <td>MODERN</td>
    </tr>
	    <tr>
      <td>FAÇADE OPTIONS</td>
      <td>TWO</td>
      <td>FOUR</td>
    </tr>
	    <tr>
      <td>NO OF FLOORPLAN REVISIONS</td>
      <td>UPTO FIVE</td>
      <td>UPTO TEN</td>
    </tr>
	    <tr>
      <td>FURNITURE LAYOUT</td>
      <td>NO</td>
      <td>YES</td>
    </tr>
	    <tr>
      <td>STRUCTURAL DESIGN</td>
    <td>YES</td>
      <td>YES</td>
    </tr>
	  <tr>
      <td>PLUMBING DESIGN</td>
    <td>NO</td>
      <td>NO</td>
    </tr>
	  <tr>
      <td>ELECTRICAL DESIGN</td>
    <td>NO</td>
      <td>NO</td>
    </tr>
	  <tr>
      <td>2D LANDSCAPE LAYOUT</td>
    <td>NO</td>
      <td>YES</td>
    </tr>
  </tbody>
</table>
<div class="link-box"><a href="<?php echo base_url();?>contactus" class="theme-btn btn-style-three">Contact Us</a></div>
</div>
</table>
</div>
</div>
</section>
 

    <section class="services-section style-five projects-bg">
        <div class="auto-container">   
            <div class="sec-title text-left">
                <h2>Some of our Designs</h2>
            </div> 
            <div class="services-box style-two row clearfix">
                <div class="services-carousel owl-carousel owl-theme">
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-1.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>interiors">interiors Projects</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-2.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>architecture">Conceptual Architecture</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-3.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Apartment Buildings</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-1.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>interiors">interiors Projects</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-2.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>architecture">Conceptual Architecture</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-3.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Apartment Buildings</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-1.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>interiors">interiors Projects</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-2.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>architecture">Conceptual Architecture</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-3.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Apartment Buildings</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
   


    <section id="features" class="features-area item-full text-center cell-items default-padding" style="background-image:url(<?php echo base_url();?>application/images/background/24.jpg);">
        <div class="container">
            <br><br>
            <div class="sec-title text-left why-choose">
                <h2>Why Choose Unico Designs</h2>
            </div>
                <div class="row features-items">
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                              <img src="<?php echo base_url();?>application/images/icons/1.png" alt="">
                            </div>
                            <div class="info">
                                <h4>No Subcontractors</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/2.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Professional Project Management</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/3.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Unique And Modern Designs</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/4.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Quality</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/5.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Process</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/6.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Adherence To Timelines</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/7.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Competitive Pricing</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/8.png" alt="">
                            </div>
                            <div class="info">
                                <h4>High-Quality Design</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/9.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Transparency</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/10.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Brand/Trustworthy</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/11.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Professional Customer Service</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/12.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Hassle-Free Service</h4>
                               
                            </div>
                        </div>
                    </div>
            </div>
            <br>  <br>  <br>  <br>  <br>
        </div>
    </section>

    	    <section class="clients-section style-four">
        <div class="auto-container">
		<div class="sec-title text-left">
                <h2>Our Brands</h2>
            </div>
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/5.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/5.png" alt=""></a></figure></li>
                </ul>
            </div>
        </div>
    </section>


<br><br>

    <?php include_once("footer.php"); ?>


</div>

<!-- Color Palate / Color Switcher -->


<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="<?php echo base_url();?>application/js/jquery.js"></script> 
<script src="<?php echo base_url();?>application/js/popper.min.js"></script>
<script src="<?php echo base_url();?>application/js/bootstrap.min.js"></script>

<script src="<?php echo base_url();?>application/js/jquery.fancybox.js"></script>
<script src="<?php echo base_url();?>application/js/owl.js"></script>
<script src="<?php echo base_url();?>application/js/wow.js"></script>
<script src="<?php echo base_url();?>application/js/appear.js"></script>
<script src="<?php echo base_url();?>application/js/isotope.js"></script>
<script src="<?php echo base_url();?>application/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo base_url();?>application/js/jquery-ui.js"></script>
<script src="<?php echo base_url();?>application/js/mixitup.js"></script>
<script src="<?php echo base_url();?>application/js/script.js"></script>
<!-- Color Setting -->
<script src="<?php echo base_url();?>application/js/color-settings.js"></script>




</body>
</html>