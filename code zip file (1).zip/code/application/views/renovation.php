<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Unico Designs</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">   
<link href="css/color-switcher-design.css" rel="stylesheet">
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
</head>

<body>

<div class="page-wrapper">
  
    <?php include_once("header.php"); ?>

     <section class="banner-section">
        <div class="carousel-column">
            <div class="carousel-outer">
                <ul class="banner-carousel owl-carousel owl-theme">

                    <!-- Slide Item -->
                    <li class="slide-item" style="background-image: url(images/main-slider/image-8.jpg);">
                        <div class="auto-container">
						<div class="row">
						<div class="col-lg-8">
						  <div class="content-box">
                                <h1>We are <br> <strong>Unico Designs</strong></h1>
                                <div class="text">Quality Homes . Transparent Service . <br> Great Value for Money.</div>
                                <div class="link-box">
                                    <a href="#" class="theme-btn btn-style-one">Contact Us</a>
                                </div>
                            </div>
						</div>
						<div class="col-lg-4">
						<div class="content-box">
                           
                             <form>
                             <h3>Quick Enquiry</h3>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Name">
  </div>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Phone">
  </div>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Email">
  </div>

  <div class="form-row">
    <div class="form-group col-md-12">
      <select id="inputState" class="form-control">
        <option selected>Select Services </option>
        <option>Construction</option>
        <option>Architecture</option>
        <option>Interior</option>
        <option>Renovations</option>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-12">
      <select id="inputState" class="form-control">
        <option selected>Select your city</option>
        <option>Hyderabad</option>
        <option>Khammam</option>
        <option>Visakhapatnam</option>
      </select>
    </div>
  </div>


  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
       Apply Terms and Condations
      </label>
    </div>
  </div>
  <div class="form-group col-lg-12 col-md-12 col-sm-12">
                                            <button class="theme-btn btn-style-four" type="submit" name="submit-form">Submit Now</button>
                                        </div>  <br>
</form>
                            </div>
						</div>
						</div>
						
                          
                        </div>
                    </li>

                
                

                </ul>
                <ul class="thumbs-carousel owl-carousel owl-theme">
              
                </ul>
            </div>
        </div>

       
    </section>


<section class="services-section style-seven" style="background-image: url(images/background/1.jpg);">
        <div class="auto-container">    
            <div class="sec-title text-left">
                <h2>Our Expertise</h2>
            </div>
            <div class="row clearfix">
    <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-img">
 <img src="images/resource/service-1.jpg" alt=" ">
  <h2>Civil Works</h2>
    </div>
    <div class="flip-box-back">
      <h2>All kind of Civil works wil be handled with Quality material.</h2>
    </div>
  </div>
</div>
    </div>
	
	    <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-img">
<img src="images/resource/service-2.jpg" alt=" ">
  <h2>Home Decoration</h2>
    </div>
    <div class="flip-box-back">
      <h2>Interior design and decoration will be handled with cool designs.</h2>
    </div>
  </div>
</div>
    </div>
	
	
	    <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-img">
 <img src="images/resource/service-3.jpg" alt=" ">
  <h2>Interior Renovation</h2>
    </div>
    <div class="flip-box-back">
      <h2>Interior renovation will be handled as per your requirements.</h2>
    </div>
  </div>
</div>
    </div>
	
            </div>
			<br/><br/><br/>
			 <div class="row clearfix">
    <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-img">
 <img src="images/resource/service-4.jpg" alt=" ">
  <h2>Kitchen Renovation</h2>
    </div>
    <div class="flip-box-back">
      <h2>Kitchen can be renovated or remodeled based on your requirements.</h2>
    </div>
  </div>
</div>
    </div>
	
	    <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-img">
<img src="images/resource/service-5.jpg" alt=" ">
  <h2>Civil Works</h2>
    </div>
    <div class="flip-box-back">
      <h2>All kind of Civil works wil be handled with Quality material.</h2>
    </div>
  </div>
</div>
    </div>
	
	
	    <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-img">
 <img src="images/resource/service-1.jpg" alt=" ">
  <h2>Flooring & Dado works</h2>
    </div>
    <div class="flip-box-back">
      <h2>Any kind of flooring renovation or new flooring can be done.</h2>
    </div>
  </div>
</div>
    </div>
	
            </div>
        </div>
        <br>
    </section>

 <section class="offer-section">
        <div class="auto-container">
		<div class="sec-title text-left">
                <h2>Contact Form</h2>
            </div>
            <div class="row">
                <div class="form-column order-last col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="discount-form">
                            <!--Comment Form-->
                            <form method="post" action="http://html.commonsupport.xyz/2019/Altoona/blog.html">
                                <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="username" placeholder="Name" required="">
                                    </div>
                                    
                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="email" name="email" placeholder="Mobile" required="">
                                    </div>

                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" placeholder="Email" required="">
                                    </div>
									
									  <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" placeholder="Location" required="">
                                    </div>
									
									  <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" placeholder="City" required="">
                                    </div>
									
									  <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" placeholder="State" required="">
                                    </div>
									  <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                      <select id="inputState" class="form-control">
        <option selected="">Select Services </option>
        <option>Construction</option>
        <option>Architecture</option>
        <option>Interior</option>
        <option>Renovations</option>
      </select>
                                    </div>
                                    
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <textarea name="message" placeholder="Massage"></textarea>
                                    </div>
                                    
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group text-center">
                                        <button class="theme-btn btn-style-one" type="submit" name="submit-form">send Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
    </section>

    <section id="features" class="features-area item-full text-center cell-items default-padding" style="background-image:url(images/background/24.jpg);">
        <div class="container">
            <br><br>
            <div class="sec-title text-left why-choose">
                <h2>Why Choose Unico Designs</h2>
            </div>
                <div class="row features-items">
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                              <img src="images/icons/1.png" alt="">
                            </div>
                            <div class="info">
                                <h4>No Subcontractors</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/2.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Professional Project Management</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/3.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Unique And Modern Designs</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/4.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Quality</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/5.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Process</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/6.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Adherence To Timelines</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/7.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Competitive Pricing</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/8.png" alt="">
                            </div>
                            <div class="info">
                                <h4>High-Quality Design</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/9.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Transparency</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/10.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Brand/Trustworthy</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/11.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Professional Customer Service</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/12.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Hassle-Free Service</h4>
                               
                            </div>
                        </div>
                    </div>
            </div>
            <br>  <br>  <br>  <br>  <br>
        </div>
    </section>

    	    <section class="clients-section style-four">
        <div class="auto-container">
		<div class="sec-title text-left">
                <h2>Our Brands</h2>
            </div>
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                </ul>
            </div>
        </div>
    </section>


<br><br>

    <?php include_once("footer.php"); ?>


</div>

<!-- Color Palate / Color Switcher -->


<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/script.js"></script>
<!-- Color Setting -->
<script src="js/color-settings.js"></script>




</body>
</html>