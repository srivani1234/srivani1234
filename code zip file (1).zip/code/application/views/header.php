<?php include_once('common/connection.php');?>
<link href="<?php echo base_url();?>application/css/style.css" rel="stylesheet">
<header class="main-header header-style-one">
        <div class="auto-container">
            <div class="main-box clearfix">
                <div class="logo-box">
                    <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
                </div>

                <div class="nav-outer clearfix">
                    <!-- Main Menu -->
                    <nav class="main-menu navbar-expand-md ">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon flaticon-menu"></span>
                            </button>
                        </div>
                        
                        <div class="collapse navbar-collapse clearfix" id="navbarSupportedContent">
                            <ul class="navigation clearfix">
                            <li><a href="<?php echo base_url();?>construction">Construction</a></li>
                            <li><a href="<?php echo base_url();?>architectures">Architecture</a></li>
                            <li><a href="interiors.php">Interiors</a></li>
                            <li><a href="renovation.php">Renovations</a></li>
                            <li class="dropdown"><a href="#">More</a>
                            <ul>
                            <li>
							<a href="packages.php"> Packages  </a></li>
                            <li><a href="projects.php">  Projects  </a></li>
                            <li><a href="about-us.php">  About Us  </a></li>
                            <li><a href="career.php">   Careers  </a></li>
                            <li><a href="contact-us.php">   Contact Us  </a></li>
                            </ul>
                            </li>
                            </ul>
                        </div>
                    </nav>                      
                    <div class="outer-box clearfix">
                        <div class="header-searchbar">
                            <i class="fa fa-phone"></i> +91 9876543210
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		<div class="sticky-header animated slideInDown">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index.php" title=""><img src="images/logo-small.png" alt="" title=""></a>
                </div>
                <!--Right Col-->
                <div class="pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-collapse show collapse clearfix">
                            <ul class="navigation clearfix">
                            <li><a href="construction.php">Construction</a></li>
                            <li><a href="architecture.php">Architecture</a></li>
                            <li><a href="interiors.php">Interiors</a></li>
                            <li><a href="renovation.php">Renovations</a></li>
                             <li class="dropdown"><a href="#">More</a>
                                        <ul>
                                            <li><a href="packages.php"> Packages  </a></li>
                                            <li><a href="projects.php">  Projects  </a></li>
                                            <li><a href="about-us.php">  About Us  </a></li>
                                            <li><a href="career.php">   Careers  </a></li>
                                            <li><a href="contact-us.php">   Contact Us  </a></li>
                                        </ul>
                                    <div class="dropdown-btn"><span class="fa fa-angle-down"></span></div></li>
                                    <li><a href="tel:+91 9876543210 "><i class="fa fa-phone"></i> +91 9876543210 </a></li>
                                </ul> 
                                
                        </div>
                    </nav>
                    
                </div>
            </div>
        </div>
    </header>