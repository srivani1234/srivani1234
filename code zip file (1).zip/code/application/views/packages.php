<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Unico Designs</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">   
<link href="css/color-switcher-design.css" rel="stylesheet">
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
</head>

<body>

<div class="page-wrapper">
  
    <?php include_once("header.php"); ?>

    
    <section class="page-title" style="background-image:url(images/background/24.jpg);">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>Packages</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="index.php"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span> Packages </li>
                </ul>
            </div>
        </div>
    </section>
    

 <section class="filters packages">
	 <div class="container">
	 <div class="sec-title text-left">
        <h2>Construction Packages</h2>
    </div>
	  <div class="row">
      <div class="col-lg-12">
  <ul class="filters-content">
    <button class="filters__button is-active" data-target="#projects">
 <h3>Silver</h3> Rs.1645/sft /  <strike>Rs.1745/sft</strike>
  <p>(Including GST)</p>
    </button>
    <button class="filters__button" data-target="#skills">
   <h3>Gold</h3> Rs.1775/sft <strike>  Rs.1875/sft </strike>
    <p>(Including GST)</p>
    </button>
    <button class="filters__button" data-target="#experience">
      <h3>Diamond</h3> Rs.1995/sft <strike>  Rs.2095/sft </strike>
	  <p>(Including GST)</p>
    </button>
	 <button class="filters__button" data-target="#experience">
      <h3>Platinum</h3> Rs.2145/sft <strike>   Rs.2245/sft </strike>
	  <p>(Including GST)</p>
    </button>
	
  </ul>

  <div>
    <div data-content class="is-active" id="projects">
	<br/>
<div class="container d-flex">
  <ul id="tabs" class="nav nav-tabs" role="tablist">
    <li class="nav-item">
      <a id="tab-A" href="#pane-A" class="nav-link active" data-toggle="tab" role="tab">Design & Drawings</a>
    </li>
    <li class="nav-item">
      <a id="tab-B" href="#pane-B" class="nav-link" data-toggle="tab" role="tab">Structure & Civil</a>
    </li>
    <li class="nav-item">
      <a id="tab-C" href="#pane-C" class="nav-link" data-toggle="tab" role="tab">Kitchen</a>
    </li>
	  <li class="nav-item">
      <a id="tab-d" href="#pane-d" class="nav-link" data-toggle="tab" role="tab">Bathroom</a>
    </li>
	  <li class="nav-item">
      <a id="tab-e" href="#pane-e" class="nav-link" data-toggle="tab" role="tab">Woodwork</a>
    </li>
	 <li class="nav-item">
      <a id="tab-f" href="#pane-f" class="nav-link" data-toggle="tab" role="tab">Painting</a>
    </li>
	 <li class="nav-item">
      <a id="tab-g" href="#pane-g" class="nav-link" data-toggle="tab" role="tab">Flooring</a>
    </li>
	<li class="nav-item">
      <a id="tab-h" href="#pane-h" class="nav-link" data-toggle="tab" role="tab">Electrical</a>
    </li>
	<li class="nav-item">
      <a id="tab-i" href="#pane-i" class="nav-link" data-toggle="tab" role="tab">Water Tanks</a>
    </li>
	<li class="nav-item">
      <a id="tab-j" href="#pane-j" class="nav-link" data-toggle="tab" role="tab">Fabrication</a>
    </li>
	<li class="nav-item">
      <a id="tab-k" href="#pane-k" class="nav-link" data-toggle="tab" role="tab">Exclusions Package</a>
    </li>
	<li class="nav-item">
      <a id="tab-l" href="#pane-l" class="nav-link" data-toggle="tab" role="tab">Warranty</a>
    </li>
<li class="nav-item">
      <a id="tab-m" href="#pane-m" class="nav-link" data-toggle="tab" role="tab">Note</a>
    </li>
  </ul>

  <div id="content" class="tab-content" role="tablist">
    <div id="pane-A" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="tab-A">
	<div class="row">
	<div class="col-lg-6">
	<div class="packages-design">
	 <h3> Design & Drawings </h3>
	 <p><strong>Package Includes:</strong> </p>
     <ul class="list-style-one">
      <li>Detailed 2D floor plans will be provided.</li>
	  </ul>
	  <p><strong>Note:</strong> This Floor plan is just for your reference only, Floor plan for each project will be designed as per client’s requirements. </p>
	  <hr/>
	  <h4>Building Elevation:</h4>
	   <ul class="list-style-one">
      <li> 2D Preliminary elevation view. </li>
	  <li> 3D Elevation rendered view.</li>
	  <li> 2D elevation working drawings.</li>
	  </ul>
	   <p><strong>Note:</strong> This elevation image is just for your reference only, Elevation for each project will be designed as per client’s taste and requirement. </p>
	   <hr/>
	   <h4>Structural Drawings:</h4>
	     <ul class="list-style-one">
      <li> Structural Analysis </li>
	  <li> Center line marking drawings </li>
	  <li> Excavation drawings </li>
	  <li> Sump drawings </li>
	  <li> Footings and Columns drawings </li>
	  <li> Plinth beam drawings </li>
	  <li> Roof slab shuttering drawings </li>
	  <li> Roof slab reinforcement drawings </li>
	  <li> Roof slab and Beam drawings for each level </li>
	  <li> Staircase drawings </li>
	  </ul>
	  </div>
	</div>
	<div class="col-lg-6">
	<div class="packages-design">
<h3> Sample Design </h3>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/resource/service-1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<h4>Plumbing & Electrical Drawings:</h4>
   <ul class="list-style-one">
      <li> Detailed Plumbing and Electrical drawings will be provided</li>
	  </ul>
	  <div class="quality-img">
	      <img src="images/iso.jpeg">
	  </div>
	  </div>
	</div>
	</div>
    
    </div>

    <div id="pane-B" class="card tab-pane fade" role="tabpanel" aria-labelledby="tab-B">
    
   <div class="row">
	<div class="col-lg-6">
	<div class="packages-design">
	 <h3> Structure & Civil </h3>
	 <p><strong>Package Includes:</strong> </p>
     <ul class="list-style-one">
      <li>Detailed 2D floor plans will be provided.</li>
	  </ul>
	  <p><strong>Note:</strong> This Floor plan is just for your reference only, Floor plan for each project will be designed as per client’s requirements. </p>
	  <hr/>
	  <h4>Building Elevation:</h4>
	   <ul class="list-style-one">
      <li> 2D Preliminary elevation view. </li>
	  <li> 3D Elevation rendered view.</li>
	  <li> 2D elevation working drawings.</li>
	  </ul>
	   <p><strong>Note:</strong> This elevation image is just for your reference only, Elevation for each project will be designed as per client’s taste and requirement. </p>
	   <hr/>
	   <h4>Structural Drawings:</h4>
	     <ul class="list-style-one">
      <li> Structural Analysis </li>
	  <li> Center line marking drawings </li>
	  <li> Excavation drawings </li>
	  <li> Sump drawings </li>
	  <li> Footings and Columns drawings </li>
	  <li> Plinth beam drawings </li>
	  <li> Roof slab shuttering drawings </li>
	  <li> Roof slab reinforcement drawings </li>
	  <li> Roof slab and Beam drawings for each level </li>
	  <li> Staircase drawings </li>
	  </ul>
	  </div>
	</div>
	<div class="col-lg-6">
	<div class="packages-design">
<h3> Sample Design </h3>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/resource/service-1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<h4>Plumbing & Electrical Drawings:</h4>
   <ul class="list-style-one">
      <li> Detailed Plumbing and Electrical drawings will be provided</li>
	  </ul>
	  <div class="quality-img">
	      <img src="images/iso.jpeg">
	  </div>
	  </div>
	</div>
	</div>
    </div>

    <div id="pane-C" class="card tab-pane fade" role="tabpanel" aria-labelledby="tab-C">
    <div class="row">
	<div class="col-lg-6">
	<div class="packages-design">
	 <h3> Kitchen </h3>
	 <p><strong>Package Includes:</strong> </p>
     <ul class="list-style-one">
      <li>Detailed 2D floor plans will be provided.</li>
	  </ul>
	  <p><strong>Note:</strong> This Floor plan is just for your reference only, Floor plan for each project will be designed as per client’s requirements. </p>
	  <hr/>
	  <h4>Building Elevation:</h4>
	   <ul class="list-style-one">
      <li> 2D Preliminary elevation view. </li>
	  <li> 3D Elevation rendered view.</li>
	  <li> 2D elevation working drawings.</li>
	  </ul>
	   <p><strong>Note:</strong> This elevation image is just for your reference only, Elevation for each project will be designed as per client’s taste and requirement. </p>
	   <hr/>
	   <h4>Structural Drawings:</h4>
	     <ul class="list-style-one">
      <li> Structural Analysis </li>
	  <li> Center line marking drawings </li>
	  <li> Excavation drawings </li>
	  <li> Sump drawings </li>
	  <li> Footings and Columns drawings </li>
	  <li> Plinth beam drawings </li>
	  <li> Roof slab shuttering drawings </li>
	  <li> Roof slab reinforcement drawings </li>
	  <li> Roof slab and Beam drawings for each level </li>
	  <li> Staircase drawings </li>
	  </ul>
	  </div>
	</div>
	<div class="col-lg-6">
	<div class="packages-design">
<h3> Sample Design </h3>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/resource/service-1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<h4>Plumbing & Electrical Drawings:</h4>
   <ul class="list-style-one">
      <li> Detailed Plumbing and Electrical drawings will be provided</li>
	  </ul>
	  <div class="quality-img">
	      <img src="images/iso.jpeg">
	  </div>
	  </div>
	</div>
	</div>
    </div>
  </div>

</div>

    </div>

    <div data-content id="skills">
     <br/>
	 <div class="container d-flex">
  <ul id="tabs" class="nav nav-tabs" role="tablist">
    <li class="nav-item">
      <a id="tab-A" href="#pane-A" class="nav-link active" data-toggle="tab" role="tab">Design & Drawings</a>
    </li>
    <li class="nav-item">
      <a id="tab-B" href="#pane-B" class="nav-link" data-toggle="tab" role="tab">Structure & Civil</a>
    </li>
    <li class="nav-item">
      <a id="tab-C" href="#pane-C" class="nav-link" data-toggle="tab" role="tab">Kitchen</a>
    </li>
	  <li class="nav-item">
      <a id="tab-d" href="#pane-d" class="nav-link" data-toggle="tab" role="tab">Bathroom</a>
    </li>
	  <li class="nav-item">
      <a id="tab-e" href="#pane-e" class="nav-link" data-toggle="tab" role="tab">Woodwork</a>
    </li>
	 <li class="nav-item">
      <a id="tab-f" href="#pane-f" class="nav-link" data-toggle="tab" role="tab">Painting</a>
    </li>
	 <li class="nav-item">
      <a id="tab-g" href="#pane-g" class="nav-link" data-toggle="tab" role="tab">Flooring</a>
    </li>
	<li class="nav-item">
      <a id="tab-h" href="#pane-h" class="nav-link" data-toggle="tab" role="tab">Electrical</a>
    </li>
	<li class="nav-item">
      <a id="tab-i" href="#pane-i" class="nav-link" data-toggle="tab" role="tab">Water Tanks</a>
    </li>
	<li class="nav-item">
      <a id="tab-j" href="#pane-j" class="nav-link" data-toggle="tab" role="tab">Fabrication</a>
    </li>
	<li class="nav-item">
      <a id="tab-k" href="#pane-k" class="nav-link" data-toggle="tab" role="tab">Exclusions Package</a>
    </li>
	<li class="nav-item">
      <a id="tab-l" href="#pane-l" class="nav-link" data-toggle="tab" role="tab">Warranty</a>
    </li>
<li class="nav-item">
      <a id="tab-m" href="#pane-m" class="nav-link" data-toggle="tab" role="tab">Note</a>
    </li>
  </ul>

  <div id="content" class="tab-content" role="tablist">
    <div id="pane-A" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="tab-A">
	<div class="row">
	<div class="col-lg-6">
	<div class="packages-design">
	 <h3> Design & Drawings </h3>
	 <p><strong>Package Includes:</strong> </p>
     <ul class="list-style-one">
      <li>Detailed 2D floor plans will be provided.</li>
	  </ul>
	  <p><strong>Note:</strong> This Floor plan is just for your reference only, Floor plan for each project will be designed as per client’s requirements. </p>
	  <hr/>
	  <h4>Building Elevation:</h4>
	   <ul class="list-style-one">
      <li> 2D Preliminary elevation view. </li>
	  <li> 3D Elevation rendered view.</li>
	  <li> 2D elevation working drawings.</li>
	  </ul>
	   <p><strong>Note:</strong> This elevation image is just for your reference only, Elevation for each project will be designed as per client’s taste and requirement. </p>
	   <hr/>
	   <h4>Structural Drawings:</h4>
	     <ul class="list-style-one">
      <li> Structural Analysis </li>
	  <li> Center line marking drawings </li>
	  <li> Excavation drawings </li>
	  <li> Sump drawings </li>
	  <li> Footings and Columns drawings </li>
	  <li> Plinth beam drawings </li>
	  <li> Roof slab shuttering drawings </li>
	  <li> Roof slab reinforcement drawings </li>
	  <li> Roof slab and Beam drawings for each level </li>
	  <li> Staircase drawings </li>
	  </ul>
	  </div>
	</div>
	<div class="col-lg-6">
	<div class="packages-design">
<h3> Sample Design </h3>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/resource/service-1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<h4>Plumbing & Electrical Drawings:</h4>
   <ul class="list-style-one">
      <li> Detailed Plumbing and Electrical drawings will be provided</li>
	  </ul>
	  <div class="quality-img">
	      <img src="images/iso.jpeg">
	  </div>
	  </div>
	</div>
	</div>
    
    </div>

    <div id="pane-B" class="card tab-pane fade" role="tabpanel" aria-labelledby="tab-B">
    
   <div class="row">
	<div class="col-lg-6">
	<div class="packages-design">
	 <h3> Structure & Civil </h3>
	 <p><strong>Package Includes:</strong> </p>
     <ul class="list-style-one">
      <li>Detailed 2D floor plans will be provided.</li>
	  </ul>
	  <p><strong>Note:</strong> This Floor plan is just for your reference only, Floor plan for each project will be designed as per client’s requirements. </p>
	  <hr/>
	  <h4>Building Elevation:</h4>
	   <ul class="list-style-one">
      <li> 2D Preliminary elevation view. </li>
	  <li> 3D Elevation rendered view.</li>
	  <li> 2D elevation working drawings.</li>
	  </ul>
	   <p><strong>Note:</strong> This elevation image is just for your reference only, Elevation for each project will be designed as per client’s taste and requirement. </p>
	   <hr/>
	   <h4>Structural Drawings:</h4>
	     <ul class="list-style-one">
      <li> Structural Analysis </li>
	  <li> Center line marking drawings </li>
	  <li> Excavation drawings </li>
	  <li> Sump drawings </li>
	  <li> Footings and Columns drawings </li>
	  <li> Plinth beam drawings </li>
	  <li> Roof slab shuttering drawings </li>
	  <li> Roof slab reinforcement drawings </li>
	  <li> Roof slab and Beam drawings for each level </li>
	  <li> Staircase drawings </li>
	  </ul>
	  </div>
	</div>
	<div class="col-lg-6">
	<div class="packages-design">
<h3> Sample Design </h3>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/resource/service-1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<h4>Plumbing & Electrical Drawings:</h4>
   <ul class="list-style-one">
      <li> Detailed Plumbing and Electrical drawings will be provided</li>
	  </ul>
	  <div class="quality-img">
	      <img src="images/iso.jpeg">
	  </div>
	  </div>
	</div>
	</div>
    </div>

    <div id="pane-C" class="card tab-pane fade" role="tabpanel" aria-labelledby="tab-C">
    <div class="row">
	<div class="col-lg-6">
	<div class="packages-design">
	 <h3> Kitchen </h3>
	 <p><strong>Package Includes:</strong> </p>
     <ul class="list-style-one">
      <li>Detailed 2D floor plans will be provided.</li>
	  </ul>
	  <p><strong>Note:</strong> This Floor plan is just for your reference only, Floor plan for each project will be designed as per client’s requirements. </p>
	  <hr/>
	  <h4>Building Elevation:</h4>
	   <ul class="list-style-one">
      <li> 2D Preliminary elevation view. </li>
	  <li> 3D Elevation rendered view.</li>
	  <li> 2D elevation working drawings.</li>
	  </ul>
	   <p><strong>Note:</strong> This elevation image is just for your reference only, Elevation for each project will be designed as per client’s taste and requirement. </p>
	   <hr/>
	   <h4>Structural Drawings:</h4>
	     <ul class="list-style-one">
      <li> Structural Analysis </li>
	  <li> Center line marking drawings </li>
	  <li> Excavation drawings </li>
	  <li> Sump drawings </li>
	  <li> Footings and Columns drawings </li>
	  <li> Plinth beam drawings </li>
	  <li> Roof slab shuttering drawings </li>
	  <li> Roof slab reinforcement drawings </li>
	  <li> Roof slab and Beam drawings for each level </li>
	  <li> Staircase drawings </li>
	  </ul>
	  </div>
	</div>
	<div class="col-lg-6">
	<div class="packages-design">
<h3> Sample Design </h3>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/resource/service-1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<h4>Plumbing & Electrical Drawings:</h4>
   <ul class="list-style-one">
      <li> Detailed Plumbing and Electrical drawings will be provided</li>
	  </ul>
	  <div class="quality-img">
	      <img src="images/iso.jpeg">
	  </div>
	  </div>
	</div>
	</div>
    </div>
  </div>

</div>
    </div>
	
	
    <div data-content id="experience">
     <br/> 
	 <div class="container d-flex">
  <ul id="tabs" class="nav nav-tabs" role="tablist">
    <li class="nav-item">
      <a id="tab-A" href="#pane-A" class="nav-link active" data-toggle="tab" role="tab">Design & Drawings</a>
    </li>
    <li class="nav-item">
      <a id="tab-B" href="#pane-B" class="nav-link" data-toggle="tab" role="tab">Structure & Civil</a>
    </li>
    <li class="nav-item">
      <a id="tab-C" href="#pane-C" class="nav-link" data-toggle="tab" role="tab">Kitchen</a>
    </li>
	  <li class="nav-item">
      <a id="tab-d" href="#pane-d" class="nav-link" data-toggle="tab" role="tab">Bathroom</a>
    </li>
	  <li class="nav-item">
      <a id="tab-e" href="#pane-e" class="nav-link" data-toggle="tab" role="tab">Woodwork</a>
    </li>
	 <li class="nav-item">
      <a id="tab-f" href="#pane-f" class="nav-link" data-toggle="tab" role="tab">Painting</a>
    </li>
	 <li class="nav-item">
      <a id="tab-g" href="#pane-g" class="nav-link" data-toggle="tab" role="tab">Flooring</a>
    </li>
	<li class="nav-item">
      <a id="tab-h" href="#pane-h" class="nav-link" data-toggle="tab" role="tab">Electrical</a>
    </li>
	<li class="nav-item">
      <a id="tab-i" href="#pane-i" class="nav-link" data-toggle="tab" role="tab">Water Tanks</a>
    </li>
	<li class="nav-item">
      <a id="tab-j" href="#pane-j" class="nav-link" data-toggle="tab" role="tab">Fabrication</a>
    </li>
	<li class="nav-item">
      <a id="tab-k" href="#pane-k" class="nav-link" data-toggle="tab" role="tab">Exclusions Package</a>
    </li>
	<li class="nav-item">
      <a id="tab-l" href="#pane-l" class="nav-link" data-toggle="tab" role="tab">Warranty</a>
    </li>
<li class="nav-item">
      <a id="tab-m" href="#pane-m" class="nav-link" data-toggle="tab" role="tab">Note</a>
    </li>
  </ul>

  <div id="content" class="tab-content" role="tablist">
    <div id="pane-A" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="tab-A">
	<div class="row">
	<div class="col-lg-6">
	<div class="packages-design">
	 <h3> Design & Drawings </h3>
	 <p><strong>Package Includes:</strong> </p>
     <ul class="list-style-one">
      <li>Detailed 2D floor plans will be provided.</li>
	  </ul>
	  <p><strong>Note:</strong> This Floor plan is just for your reference only, Floor plan for each project will be designed as per client’s requirements. </p>
	  <hr/>
	  <h4>Building Elevation:</h4>
	   <ul class="list-style-one">
      <li> 2D Preliminary elevation view. </li>
	  <li> 3D Elevation rendered view.</li>
	  <li> 2D elevation working drawings.</li>
	  </ul>
	   <p><strong>Note:</strong> This elevation image is just for your reference only, Elevation for each project will be designed as per client’s taste and requirement. </p>
	   <hr/>
	   <h4>Structural Drawings:</h4>
	     <ul class="list-style-one">
      <li> Structural Analysis </li>
	  <li> Center line marking drawings </li>
	  <li> Excavation drawings </li>
	  <li> Sump drawings </li>
	  <li> Footings and Columns drawings </li>
	  <li> Plinth beam drawings </li>
	  <li> Roof slab shuttering drawings </li>
	  <li> Roof slab reinforcement drawings </li>
	  <li> Roof slab and Beam drawings for each level </li>
	  <li> Staircase drawings </li>
	  </ul>
	  </div>
	</div>
	<div class="col-lg-6">
	<div class="packages-design">
<h3> Sample Design </h3>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/resource/service-1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<h4>Plumbing & Electrical Drawings:</h4>
   <ul class="list-style-one">
      <li> Detailed Plumbing and Electrical drawings will be provided</li>
	  </ul>
	  <div class="quality-img">
	      <img src="images/iso.jpeg">
	  </div>
	  </div>
	</div>
	</div>
    
    </div>

    <div id="pane-B" class="card tab-pane fade" role="tabpanel" aria-labelledby="tab-B">
    
   <div class="row">
	<div class="col-lg-6">
	<div class="packages-design">
	 <h3> Structure & Civil </h3>
	 <p><strong>Package Includes:</strong> </p>
     <ul class="list-style-one">
      <li>Detailed 2D floor plans will be provided.</li>
	  </ul>
	  <p><strong>Note:</strong> This Floor plan is just for your reference only, Floor plan for each project will be designed as per client’s requirements. </p>
	  <hr/>
	  <h4>Building Elevation:</h4>
	   <ul class="list-style-one">
      <li> 2D Preliminary elevation view. </li>
	  <li> 3D Elevation rendered view.</li>
	  <li> 2D elevation working drawings.</li>
	  </ul>
	   <p><strong>Note:</strong> This elevation image is just for your reference only, Elevation for each project will be designed as per client’s taste and requirement. </p>
	   <hr/>
	   <h4>Structural Drawings:</h4>
	     <ul class="list-style-one">
      <li> Structural Analysis </li>
	  <li> Center line marking drawings </li>
	  <li> Excavation drawings </li>
	  <li> Sump drawings </li>
	  <li> Footings and Columns drawings </li>
	  <li> Plinth beam drawings </li>
	  <li> Roof slab shuttering drawings </li>
	  <li> Roof slab reinforcement drawings </li>
	  <li> Roof slab and Beam drawings for each level </li>
	  <li> Staircase drawings </li>
	  </ul>
	  </div>
	</div>
	<div class="col-lg-6">
	<div class="packages-design">
<h3> Sample Design </h3>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/resource/service-1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<h4>Plumbing & Electrical Drawings:</h4>
   <ul class="list-style-one">
      <li> Detailed Plumbing and Electrical drawings will be provided</li>
	  </ul>
	  <div class="quality-img">
	      <img src="images/iso.jpeg">
	  </div>
	  </div>
	</div>
	</div>
    </div>

    <div id="pane-C" class="card tab-pane fade" role="tabpanel" aria-labelledby="tab-C">
    <div class="row">
	<div class="col-lg-6">
	<div class="packages-design">
	 <h3> Kitchen </h3>
	 <p><strong>Package Includes:</strong> </p>
     <ul class="list-style-one">
      <li>Detailed 2D floor plans will be provided.</li>
	  </ul>
	  <p><strong>Note:</strong> This Floor plan is just for your reference only, Floor plan for each project will be designed as per client’s requirements. </p>
	  <hr/>
	  <h4>Building Elevation:</h4>
	   <ul class="list-style-one">
      <li> 2D Preliminary elevation view. </li>
	  <li> 3D Elevation rendered view.</li>
	  <li> 2D elevation working drawings.</li>
	  </ul>
	   <p><strong>Note:</strong> This elevation image is just for your reference only, Elevation for each project will be designed as per client’s taste and requirement. </p>
	   <hr/>
	   <h4>Structural Drawings:</h4>
	     <ul class="list-style-one">
      <li> Structural Analysis </li>
	  <li> Center line marking drawings </li>
	  <li> Excavation drawings </li>
	  <li> Sump drawings </li>
	  <li> Footings and Columns drawings </li>
	  <li> Plinth beam drawings </li>
	  <li> Roof slab shuttering drawings </li>
	  <li> Roof slab reinforcement drawings </li>
	  <li> Roof slab and Beam drawings for each level </li>
	  <li> Staircase drawings </li>
	  </ul>
	  </div>
	</div>
	<div class="col-lg-6">
	<div class="packages-design">
<h3> Sample Design </h3>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/resource/service-1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/resource/service-3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<h4>Plumbing & Electrical Drawings:</h4>
   <ul class="list-style-one">
      <li> Detailed Plumbing and Electrical drawings will be provided</li>
	  </ul>
	  <div class="quality-img">
	      <img src="images/iso.jpeg">
	  </div>
	  </div>
	</div>
	</div>
    </div>
  </div>

</div>
    </div>
	
	
  </div>
	  </div>
       </div>
	    </div>
    </section>
	

    
	
	
	
	<section id="features" class="features-area item-full text-center cell-items default-padding" style="background-image:url(images/background/24.jpg);">
        <div class="container">
            <br><br>
            <div class="sec-title text-left why-choose">
                <h2>Why Choose Unico Designs</h2>
            </div>
                <div class="row features-items">
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                              <img src="images/icons/1.png" alt="">
                            </div>
                            <div class="info">
                                <h4>No Subcontractors</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/2.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Professional Project Management</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/3.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Unique And Modern Designs</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/4.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Quality</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/5.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Process</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/6.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Adherence To Timelines</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/7.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Competitive Pricing</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/8.png" alt="">
                            </div>
                            <div class="info">
                                <h4>High-Quality Design</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/9.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Transparency</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/10.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Brand/Trustworthy</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/11.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Professional Customer Service</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="images/icons/12.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Hassle-Free Service</h4>
                               
                            </div>
                        </div>
                    </div>
            </div>
            <br>  <br>  <br>  
        </div>
    </section>
	
	
	<section class="gallery-section gallery-section-2">
	 <div class="container">
	 <div class="sec-title text-left">
                <h2>The Unico Designs Advantage</h2>
            </div>
	   <div class="row">
       <div class="col-lg-12">
	   <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"> </th>
      <th scope="col">Unico Designs</th>
      <th scope="col">Typical Experience</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">PRICE</th>
      <td>
	  <ul class="list-style-one">
      <li>Best price guarantee</li>
	  <li>Prices per Square feet</li>
	  <li>Transparent and No hidden costs</li>
	  </ul>
	  </td>
      <td>
	   <ul class="list-style-one">
      <li>Comparatively higher prices</li>
	  <li>Lumpsum charges</li>
	  <li>Price hike between first quote and final cost</li>
	  </ul>
	  </td>
    </tr>
	 <tr>
      <th scope="row">QUALITY</th>
      <td>
	  <ul class="list-style-one">
      <li>Branded material</li>
	  <li>140+ Quality checks</li>
	  <li>ISO Quality standards</li>
	  <li>Quality Finishing</li>
	  </ul>
	  </td>
      <td>
	   <ul class="list-style-one">
      <li>Inferior materials used to cut the costs</li>
	  <li>No quality checks</li>
	  <li>Poor standards</li>
	  <li>Poor finishing</li>
	  </ul>
	  </td>
    </tr>
    <tr>
     <th scope="row">SUB-CONTRACTORS</th>
     <td>
	 <ul class="list-style-one">
     <li>NO Sub-Contractors</li>
	 <li>In-house project management, No third-party involvement.</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>YES</li>
	 <li>Mostly outsourced to Sub-contractors</li>
	  </ul>
	  </td>
    </tr>
	
	    <tr>
     <th scope="row">TRANSPARENCY</th>
     <td>
	 <ul class="list-style-one">
     <li>Transparent at every level</li>
	 <li>Pricing, Material specification or documentation and Process.</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>Limited to No transparency</li>
	 <li>NO</li>
	  </ul>
	  </td>
    </tr>
	
	    <tr>
     <th scope="row">CONVINIENCE</th>
     <td>
	 <ul class="list-style-one">
     <li>In-House Team and One-stop solution</li>
	 <li>We take care from Design to handover including Civil, Electrical, Plumbing and False ceiling works.</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>Hassle experience to No support</li>
	 <li>Mostly they outsource.</li>
	  </ul>
	  </td>
    </tr>
	
	    <tr>
     <th scope="row">DESIGN</th>
     <td>
	 <ul class="list-style-one">
     <li>Personalized Interior Designs by Senior Architects</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>Cookie-cutter designs by Junior Architects mostly</li>
	  </ul>
	  </td>
    </tr>
	
	
	    <tr>
     <th scope="row">TIMELINES</th>
     <td>
	 <ul class="list-style-one">
     <li>Standard project can be delivered less than 45days time.</li>
	 <li>On-Time Project Completion with regular updates and Project tracking</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>Delays in project completion and unreliable timelines</li>
	 <li>Poor communication on Project updates/delays</li>
	  </ul>
	  </td>
    </tr>
	
	    <tr>
     <th scope="row">WARRANTY</th>
     <td>
	 <ul class="list-style-one">
     <li>Upto 10-years servicewarranty.</li>
	 <li>We provide after sales customer service</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>No warranty or Warranty for namesake</li>
	 <li>NO after sales customer service</li>
	  </ul>
	  </td>
    </tr>
	
 
  </tbody>
</table>
	   </div>
      </div>
	 </div>
	</section>
	
	    <section class="clients-section style-four">
        <div class="auto-container">
		<div class="sec-title text-left">
                <h2>Our Brands</h2>
            </div>
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                </ul>
            </div>
        </div>
    </section>


<br><br>

    <?php include_once("footer.php"); ?>


</div>

<!-- Color Palate / Color Switcher -->


<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/script.js"></script>
<!-- Color Setting -->
<script src="js/color-settings.js"></script>

   <script>
const tabs = document.querySelectorAll("[data-target]"),
  tabContents = document.querySelectorAll("[data-content]");

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const target = document.querySelector(tab.dataset.target);

    tabContents.forEach((tc) => {
      tc.classList.remove("is-active");
    });
    target.classList.add("is-active");

    tabs.forEach((t) => {
      t.classList.remove("is-active");
    });
    tab.classList.add("is-active");
  });
});


</script>


</body>
</html>