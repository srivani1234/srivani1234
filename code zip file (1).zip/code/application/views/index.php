<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Unico Designs</title>

<link href="<?php echo base_url();?>application/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url();?>application/css/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>application/css/responsive.css" rel="stylesheet">   
<link href="<?php echo base_url();?>application/css/color-switcher-design.css" rel="stylesheet">
<link id="theme-color-file" href="<?php echo base_url();?>application/css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="<?php echo base_url();?>application/images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>application/images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
</head>

<body>

<div class="page-wrapper">
  
    <?php include_once("header.php"); ?>

    <section class="banner-section-two" style="background-image: url(<?php echo base_url();?>application/images/main-slider/image-4.jpg);">
        <div class="auto-container">
            <div class="row outer-column clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="text-column">
                        <div class="content-box">
                            <h1>We are <b>Unico Designs</b></h1>
                            <div class="text">Quality Homes . Transparent Service .
                                Great Value for Money.</div>
                            <div class="link-box">
                                <a href="<?php echo base_url();?>contactus" class="theme-btn btn-style-one">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="form-column">
                        <div class="content-box">
                             <form>
                             <h3>Quick Enquiry</h3>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Name">
  </div>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Phone">
  </div>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Email">
  </div>

  <div class="form-row">
    <div class="form-group col-md-12">
      <select id="inputState" class="form-control">
        <option selected>Select Services</option>
        <option><a href="<?php echo base_url();?>construction">Construction</a></option>
        <option><a href="<?php echo base_url();?>architecture">Architecture</a></option>
        <option><a href="<?php echo base_url();?>interiors">Interior</a></option>
        <option><a href="<?php echo base_url();?>renovation">Renovations</a></option>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-12">
      <select id="inputState" class="form-control">
        <option selected>Select your city</option>
        <option>Hyderabad</option>
        <option>Khammam</option>
        <option>Visakhapatnam</option>
      </select>
    </div>
  </div>


  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
       Apply Terms and Condations
      </label>
    </div>
  </div>
  <div class="form-group col-lg-12 col-md-12 col-sm-12">
                                            <button class="theme-btn btn-style-four" type="submit" name="submit-form">Submit Now</button>
                                        </div>  <br>
</form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 
      <section class="services-section style-seven" style="background-image: url(<?php echo base_url();?>application/images/background/1.jpg);">
        <div class="auto-container">    
            <div class="sec-title text-left">
                <h2>Our Expertise</h2>
            </div>
            <div class="row clearfix">
    <div class="col-lg-3 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
    <i class="fa fa-building" aria-hidden="true"></i>
      <h2>Interior Designing</h2>
    </div>
    <div class="flip-box-back">
      <h2>Best in class Interior designs, Quality material and Great Value.</h2>
    </div>
  </div>
</div>
    </div>


    <div class="col-lg-3 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
    <i class="fa fa-home" aria-hidden="true"></i>
      <h2>Home Construction</h2>
    </div>
    <div class="flip-box-back">
      <h2>Independent House/Villa Constructions with High standards and Quality material.</h2>
    </div>
  </div>
</div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
    <i class="fa fa-cogs"></i>
      <h2>Home Renovation</h2>
    </div>
    <div class="flip-box-back">
      <h2>Home Renovations and Remodeling with Quality material and reasonable price.</h2>
    </div>
  </div>
</div>
    </div>


    <div class="col-lg-3 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
    <i class="fa fa-map" aria-hidden="true"></i>
      <h2>Architecture & Structural</h2>
    </div>
    <div class="flip-box-back">
      <h2>Best in class Architecture includes Floor plans, 3D Elevations and Structural drawings.</h2>
    </div>
  </div>
</div>
    </div>


            </div>
        </div>
        <br>
    </section>
	
	
	<section class="filters packages packages-2">
	 <div class="container">
	 <div class="sec-title text-left">
        <h2>Unico Designs Packages</h2>
    </div>
	  <div class="row">
      <div class="col-lg-12">
  <ul class="filters-content">
    <button class="filters__button is-active" data-target="#construction">
 Construction 
    </button>
    <button class="filters__button" data-target="#interior">
  Interior Design 
    </button>
	
  </ul>

  <div>
    <div data-content="" class="is-active" id="construction">
     <div class="row">
	 <div class="col-lg-4">
	<div class="inner-box inner-box-2">
    <h3>Silver</h3>
                            <p>Rs.1645/sft <strike>Rs.1745/sft</strike> | (Including GST)</p>
                            <figure class="image-box"><img src="<?php echo base_url();?>application/images/packages/1.jpeg" alt=""></figure>
                            <div class="package-block">
                                <h3>Package Includes</h3>
                                <ul>
                                     <li><i class="fa fa-check"></i> Floor plans + Structural</li>
                                     <li><i class="fa fa-check"></i> Standard Elevation</li>
                                     <li><i class="fa fa-check"></i> Vitrified Tiles Flooring</li>
                                     <li><i class="fa fa-check"></i> Modern Bathroom and Kitchen</li>
                                     <li><i class="fa fa-check"></i> Main door</li>
                                </ul>
                                <center>   <button class="theme-btn btn-style-one" type="submit" name="submit-form">View More</button></center>
                            </div>
    </div>
    </div>
	
			 <div class="col-lg-4">
<div class="inner-box inner-box-2">
                            <h3>Gold</h3>
                            <p>Rs.1775/sft <strike>Rs.1875/sft</strike> | (Including GST)</p>
                            <figure class="image-box"><img src="<?php echo base_url();?>application/images/packages/2.jpg" alt=""></figure>
                            <div class="package-block">
                                <h3>Package Includes</h3>
                                <ul>
                                     <li><i class="fa fa-check"></i> Floor plans + Structural</li>
                                     <li><i class="fa fa-check"></i> Classic Elevation</li>
                                     <li><i class="fa fa-check"></i> Premium Vitrified Tiles Flooring</li>
                                     <li><i class="fa fa-check"></i> Modern Bathroom and Kitchen</li>
                                     <li><i class="fa fa-check"></i> Teak main door</li>
                                </ul>
                                <center>   <button class="theme-btn btn-style-one" type="submit" name="submit-form">View More</button></center>
                            </div>
                        </div>
    </div>
	
		 <div class="col-lg-4">
	<div class="inner-box inner-box-2">
                            <h3>Diamond</h3>
                            <p>Rs.1995/sft <strike>Rs.2095/sft</strike> | (Including GST)</p>
                            <figure class="image-box"><img src="<?php echo base_url();?>application/images/packages/3.jpg" alt=""></figure>
                            <div class="package-block">
                                <h3>Package Includes</h3>
                                <ul>
                                    <li><i class="fa fa-check"></i> Floor plans + Structural</li>
                                    <li><i class="fa fa-check"></i> Elegant elevation</li>
                                    <li><i class="fa fa-check"></i> Granite Flooring</li>
                                    <li><i class="fa fa-check"></i> Premium Bathroom and Kitchen</li>
                                    <li><i class="fa fa-check"></i> Premium Bathroom and Kitchen</li>
                                </ul>
                                <center>   <button class="theme-btn btn-style-one" type="submit" name="submit-form">View More</button></center>
                            </div>
                        </div>
    </div>
	 
	
	

</div>
<br/>
   <div class="row">
   	<div class="col-lg-4">
	<div class="inner-box inner-box-2">
                            <h3>Platinum</h3>
                            <p>Rs.2145/sft <strike>Rs.2245/sft</strike> | (Including GST)</p>
                            <figure class="image-box"><img src="<?php echo base_url();?>application/images/packages/4.jpeg" alt=""></figure>
                            <div class="package-block">
                                <h3>Package Includes</h3>
                                <ul>
                                    <li><i class="fa fa-check"></i> Floor plans + Structural, Electrical and Plumbing</li>
                                     <li><i class="fa fa-check"></i> Contemporary Elevation</li>
                                     <li><i class="fa fa-check"></i> Premium Granite Flooring</li>
                                     <li><i class="fa fa-check"></i> Premium Bathroom and Kitchen</li>
                                     <li><i class="fa fa-check"></i> Burma Teak
                                    </li>
                                </ul>
                                <center>   <button class="theme-btn btn-style-one" type="submit" name="submit-form">View More</button></center>
                            </div>
                        </div>
    </div>
   </div>
    </div>

    <div data-content="" id="interior" class="">
     <div class="row">
	
	
	<div class="col-lg-4">
<div class="inner-box inner-box-2">
                            <h3>State-of-the-Art</h3>
                            <figure class="image-box"><img src="<?php echo base_url();?>application/images/packages/4.jpeg" alt=""></figure>
                               <div class="package-block">
                                <h3>Package Includes</h3>
                                <ul>
                                    <li><i class="fa fa-check"></i> 2BHKS Interiors starting from 4 Lakhs*</li>
                                     <li><i class="fa fa-check"></i> 3BHKS Interiors starting from 5 Lacs*</li>
                                     <li><i class="fa fa-check"></i> 4BHKS Interiors starting from 6 Lacs*</li>
                                </ul>
                             <center>   <button class="theme-btn btn-style-one" type="submit" name="submit-form">Contact Us</button></center>
                            </div>
                        </div>
    </div>
</div>
    </div>
    
  </div>
	  </div>
       </div>
	    </div>
    </section>
	
	

   <section class="offer-section">
        <div class="auto-container">
		<div class="sec-title text-left">
                <h2>Looking for Customized Package?</h2>
            </div>
            <div class="row">
                <div class="form-column order-last col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="discount-form">
                            <!--Comment Form-->
                            <form method="post" action="#">
                                <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="username" placeholder="Name" required="">
                                    </div>
                                    
                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="email" name="email" placeholder="Mobile" required="">
                                    </div>

                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" placeholder="Email" required="">
                                    </div>
									
									  <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" placeholder="Location" required="">
                                    </div>
									
									  <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" placeholder="City" required="">
                                    </div>
									
									  <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" placeholder="State" required="">
                                    </div>
									  <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                      <select id="inputState" class="form-control">
        <option selected="">Select Services </option>
        <option><a href="<?php echo base_url();?>construction">Construction</a></option>
        <option><a href="<?php echo base_url();?>architecture">Architecture</a></option>
        <option><a href="<?php echo base_url();?>interiors">Interior</a></option>
        <option><a href="<?php echo base_url();?>renovation">Renovations</a></option>
      </select>
                                    </div>
                                    
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <textarea name="message" placeholder="Massage"></textarea>
                                    </div>
                                    
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group text-center">
                                        <button class="theme-btn btn-style-one" type="submit" name="submit-form">send Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
    </section>
 
<div class="container">
    <br><br>
    <div class="sec-title text-left">
        <h2>How It Works?</h2>
    </div>
    <div class="tabset">
        <!-- Tab 1 -->
        <input type="radio" name="tabset" id="tab1" aria-controls="marzen" checked class="active-2">
       
        <label for="tab1"><center><p class="step"> Step 1</p></center> Consultation</label>
        <!-- Tab 2 -->
        <input type="radio" name="tabset" id="tab2" aria-controls="rauchbier">
        <label for="tab2">  <center><p class="step"> Step 2</p></center> Review our work</label>
        <!-- Tab 3 -->
        <input type="radio" name="tabset" id="tab3" aria-controls="dunkles">
        <label for="tab3">  <center><p class="step"> Step 3</p></center> Place the order</label>

        <input type="radio" name="tabset" id="tab4" aria-controls="design">
        <label for="tab4"> <center><p class="step"> Step 4</p></center> Design </label>

        <input type="radio" name="tabset" id="tab5" aria-controls="tracking">
        <label for="tab5"> <center><p class="step"> Step 5</p></center>  Execution & Tracking  </label>

        <input type="radio" name="tabset" id="tab6" aria-controls="move">
        <label for="tab6"> <center><p class="step"> Step 6</p></center> Move in  </label>
        
        <div class="tab-panels">
          <section id="marzen" class="tab-panel">
            <img src="<?php echo base_url();?>application/images/steps/1.png" alt="" title="">
            <h2>Consultation</h2>
            <p>Raise an enquiry or call us on <a href="tel:+91 9876543210">+91 9876543210</a>, our
                Technical expert will get in touch with you and take all your
                detailed requirements and provide you the estimation for your
                requirement.</p>
         
        </section>
          <section id="rauchbier" class="tab-panel">
            <img src="<?php echo base_url();?>application/images/steps/2.png" alt="" title="">
            <h2>Review our work</h2>
          <p>Visit our Projects and get to know about our
            work and quality, come to office, discuss, and close the deal.</p>
          </section>

          <section id="dunkles" class="tab-panel">
            <img src="<?php echo base_url();?>application/images/steps/3.png" alt="" title="">
            <h2>Place the order</h2>
           <p>Find your good day and sign the transparent
            construction contract. It helps us to proceed further with Design.</p>
          </section>

          <section id="design" class="tab-panel">
            <img src="<?php echo base_url();?>application/images/steps/4.png" alt="" title="">
            <h2>Design</h2>
        <p>Our experienced Architect will provide you the quality
            Designs and Architecture as per your requirements and inputs.
            Discuss and finalize the Design.</p>
          </section>

          <section id="tracking" class="tab-panel">
            <img src="<?php echo base_url();?>application/images/steps/5.png" alt="" title="">
            <h2>Execution & Tracking</h2>
          <p>Project execution will be started. Our
            project management team will be updating you the daily work
            progress in the form of Photos and Videos.</p>
          </section>

          <section id="move" class="tab-panel">
            <img src="<?php echo base_url();?>application/images/steps/6.png" alt="" title="">
            <h2>Move in</h2>
           <p>We make sure the project completes on time without
            any hassles. You can Happily move into your Dream Home.</p>
          </section>
        </div>
        
      </div>

    </div>


    
    <section class="services-section style-five projects-bg">
        <div class="auto-container">   
            <div class="sec-title text-left">
                <h2>Our Recent Projects</h2>
            </div> 
            <div class="services-box style-two row clearfix">
                <div class="services-carousel owl-carousel owl-theme">
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-1.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>interiors">interiors Projects</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-2.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>architecture">Conceptual Architecture</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-3.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Apartment Buildings</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-1.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>interiors">interiors Projects</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-2.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>architecture">Conceptual Architecture</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-3.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Apartment Buildings</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-1.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>interiors">interiors Projects</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="<?php echo base_url();?>application/images/resource/service-2.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo base_url();?>architecture">Conceptual Architecture</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure><img src="images/resource/service-3.jpg" alt=" "/></figure>
                                <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Apartment Buildings</a></h3>
                                
                              
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>


    <section id="features" class="features-area item-full text-center cell-items default-padding" style="background-image:url(<?php echo base_url();?>application/images/background/24.jpg);">
        <div class="container">
            <br><br>
            <div class="sec-title text-left why-choose">
                <h2>Why Choose Unico Designs</h2>
            </div>
                <div class="row features-items">
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                              <img src="<?php echo base_url();?>application/images/icons/1.png" alt="">
                            </div>
                            <div class="info">
                                <h4>No Subcontractors</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/2.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Professional Project Management</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/3.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Unique And Modern Designs</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/4.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Quality</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/5.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Process</h4>
                               
                            </div>
                        </div>
                    </div>
                     <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/6.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Adherence To Timelines</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/7.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Competitive Pricing</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/8.png" alt="">
                            </div>
                            <div class="info">
                                <h4>High-Quality Design</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/9.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Transparency</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/10.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Brand/Trustworthy</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/11.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Professional Customer Service</h4>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 equal-height">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo base_url();?>application/images/icons/12.png" alt="">
                            </div>
                            <div class="info">
                                <h4>Hassle-Free Service</h4>
                               
                            </div>
                        </div>
                    </div>
            </div>
            <br>  <br>  <br>  <br>  <br>
        </div>
    </section>

    <section class="faq-section style-two">
        <br><br>
        <div class="auto-container">
            <div class="sec-title text-left">
                <h2>Frequently Asked Questions</h2>
            </div>
            <div class="row clearfix">
              <div class="col-lg-6">
                <div class="accordion-column col-lg-12 col-md-12 col-sm-12">
                    <div class="outer-column">
                        <div class="inner-column">
                            <ul class="accordion-box">
                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer">
                                       <span class="icon icon_right far fa-handshake"></span> 
                                    <span class="icon icon_down far fa-handshake"></span> </div>
                                   What are services Unico Designs provides?</div>  

                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">Home/Villa/Building Turn-key construction, Interior design And House renovations.</div>
                                        </div>
                                    </div>
                                </li>
                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right far fa-user"></span> <span class="icon icon_down far fa-user"></span> </div>
                                    Why should you choose Unico Designs?</div> 
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">Unico Designs is a fast growing brand for its quality & Trustworthy services with certified professionals.</div>
                                        </div>
                                    </div>
                                </li>

                          

                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right fa fa-tags"></span> <span class="icon icon_down fa fa-tags"></span> </div>
                                    Do you charge separately for Designs?</div> 
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">NO, we do not charge for Designs, it is included with the package.</div>
                                        </div>
                                    </div>
                                </li>

                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right fa fa-university"></span> 
                                        <span class="icon icon_down fa fa-university"></span> </div>
                                    Do you help with governmental approvals?</div> 
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">YES, We do help our clients with all the government approvals and Temporary electric connects.</div>
                                        </div>
                                    </div>
                                </li>

                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right fa fa-hourglass-half"></span> 
                                        <span class="icon icon_down fa fa-hourglass-half"></span> </div>
                                        How do you assure on-time completion of the project?</div> 
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">We will plan and define a schedule and timeline for each stage of the project which helps us to meet the target date and we closely monitor all the stages.</div>
                                        </div>
                                    </div>
                                </li>

                            </ul>
                            <!-- end -->
                        </div>
                    </div>
                </div>
              </div>

              <div class="col-lg-6">
                <div class="accordion-column col-lg-12 col-md-12 col-sm-12">
                    <div class="outer-column">
                        <div class="inner-column">
                            <ul class="accordion-box">
                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer">
                                       <span class="icon icon_right fa fa-check-square"></span> 
                                    <span class="icon icon_down fa fa-check-square"></span> </div>
                                    How do you monitor the work quality?</div>  

                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">A dedicated and experienced civil engineer will be assigned to the project and he will me monitoring the progress and Quality of the work.</div>
                                        </div>
                                    </div>
                                </li>
                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right fa fa-credit-card"></span> <span class="icon icon_down fa fa-credit-card"></span> </div>
                                    How is Unico Designs payment process?</div> 
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">We provide flexible Payment schedule. The project will be devided into several stages and the calculated payments will be defined for each stage. Client can make the payment for the stages by monitoring the progress.</div>
                                        </div>
                                    </div>
                                </li>

                          

                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right fa fa-address-book"></span> <span class="icon icon_down fa fa-address-book"></span> </div>
                                    Whom to contact during work?</div> 
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">A dedicated Project manager and Site engineer will be assigned to each project. Client can contact the Site engineer or project Manager for any queries.</div>
                                        </div>
                                    </div>
                                </li>

                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right fa fa-users"></span> 
                                        <span class="icon icon_down fa fa-users"></span> </div>
                                        Does the Client need to follow up the work regularly?</div> 
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">NO, Clients need not followup or worry about the work. Our team will be taking care of it. Client can enjoy our hassle-free process and service and he/she visit the project only when required.</div>
                                        </div>
                                    </div>
                                </li>

                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right fa fa-arrows-alt"></span> 
                                        <span class="icon icon_down fa fa-arrows-alt"></span> </div>
                                        How does the Client monitor the progress of the project?</div> 
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text">We will be sending the status updates through Email or Whatsapp group. Photos and Videos will be captured at site.</div>
                                        </div>
                                    </div>
                                </li>

                            </ul>
                            <!-- end -->
                        </div>
                    </div>
                </div>
              </div>
            </div>
        </div>
    </section>

    <section class="services-section style-two" >
        <div class="auto-container"> <br><br>
            <div class="sec-title text-left">
                <h2>Our Testimonials</h2>
            </div>
            <div class="services-box row clearfix">
                <div class="services-carousel-two owl-carousel owl-theme">
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="lower-content">
                               
                                <div class="text">“They are very good at their work, they will understand your requirements and provide good design and solutions for your home.”</div>
                                <h3><a href="#">Shiva Kumar</a></h3>
                            </div>
                            <div class="number-slide">01</div>
                        </div>
                    </div>
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="lower-content">
                                
                                <div class="text">“Honest, timely, trustworthy,very knowledgeable and friendly. I would definitely recommend this company to family and friends.”</div>
                                <h3><a href="#">sai</a></h3>
                            </div>
                            <div class="number-slide">02</div>
                        </div>
                    </div>
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="lower-content">
                                <div class="text">“They are very good at their work, they will understand your requirements and provide good design and solutions for your home.”</div>
                                <h3><a href="#">Prasad</a></h3>
                            </div>
                            <div class="number-slide">03</div>
                        </div>
                    </div>
                </div>
            </div>  
        </div>
    </section>

   <br><br>
    <section class="clients-section style-four">
        <div class="auto-container">
            <div class="sec-title text-left">
                <h2>Trusted Brands</h2>
            </div>
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/5.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/6.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/7.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/8.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/9.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/10.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/11.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url();?>application/images/clients/12.png" alt=""></a></figure></li>
                </ul>
            </div>
        </div>
    </section>
    <br> <br> <br>

    <?php include_once("footer.php"); ?>


</div>

<!-- Color Palate / Color Switcher -->


<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="<?php echo base_url();?>application/js/jquery.js"></script> 
<script src="<?php echo base_url();?>application/js/popper.min.js"></script>
<script src="<?php echo base_url();?>application/js/bootstrap.min.js"></script>

<script src="<?php echo base_url();?>application/js/jquery.fancybox.js"></script>
<script src="<?php echo base_url();?>application/js/owl.js"></script>
<script src="<?php echo base_url();?>application/js/wow.js"></script>
<script src="<?php echo base_url();?>application/js/appear.js"></script>
<script src="<?php echo base_url();?>application/js/isotope.js"></script>
<script src="<?php echo base_url();?>application/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo base_url();?>application/js/jquery-ui.js"></script>
<script src="<?php echo base_url();?>application/js/mixitup.js"></script>
<script src="<?php echo base_url();?>application/js/script.js"></script>
<!-- Color Setting -->
<script src="<?php echo base_url();?>application/js/color-settings.js"></script>


<script>
const tabs = document.querySelectorAll("[data-target]"),
  tabContents = document.querySelectorAll("[data-content]");

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const target = document.querySelector(tab.dataset.target);

    tabContents.forEach((tc) => {
      tc.classList.remove("is-active");
    });
    target.classList.add("is-active");

    tabs.forEach((t) => {
      t.classList.remove("is-active");
    });
    tab.classList.add("is-active");
  });
});


</script>

</body>
</html>