
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from html.commonsupport.xyz/2019/Altoona/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 28 Apr 2022 10:12:40 GMT -->
<head>
<meta charset="utf-8">
<title>Altoona - Interior Creator HTML Template | Contact Us</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">   
<!--Color Switcher Mockup-->
<link href="css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">


    <?php include_once("header.php"); ?>

    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/24.jpg);">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>Contact Us</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="index.php"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span> Contact Us</li>
                </ul>
            </div>
        </div>
    </section>

    <section class="contact-page-info">
        <div class="auto-container">
            <div class="info-column">
                <div class="inner-column">
                    <div class="contact-info row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div class="info-box"><i class="flaticon-pin"></i> <span>Location</span> <br> Hyderabad </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div class="info-box"> <i class="flaticon-phone-reciever"></i>  <span>Call us</span> <br><a href="tel:+91 9876543210">+91 9876543210</a></div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div class="info-box"> <i class="flaticon-message"></i> <span>Email</span> <br> <a href="mailto:info@unicodesigns.com">info@unicodesigns.com</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="contact-page-section" style="background-image:url(images/background/12.png)">
        <div class="auto-container">
           
            <div class="row">
            <div class="form-column col-lg-6 col-md-12 col-sm-12">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d243646.88005384957!2d78.26795710593578!3d17.41262741933413!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb99daeaebd2c7%3A0xae93b78392bafbc2!2sHyderabad%2C%20Telangana!5e0!3m2!1sen!2sin!4v1651558215994!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
                <div class="form-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <!-- Contact Form -->
                        <div class="contact-form">
                            <form method="" action="#">
                                <div class="row">
                                    <div class="form-group col-lg-12 col-md-12">
                                        <input type="text" name="username" placeholder="Name" required>
                                    </div>

                                    <div class="form-group col-lg-12 col-md-12">
                                        <input type="text" name="phone" placeholder="Phone" required>
                                    </div>

                                    <div class="form-group col-lg-12 col-md-12">
                                        <input type="email" name="email" placeholder="Email Address" required>
                                    </div>

                                    <div class="form-group col-lg-12 col-md-12">
                                        <textarea name="message" placeholder="Massage"></textarea>
                                    </div>
                                    
                                    <div class="form-group col-lg-12 col-md-12 text-center">
                                        <button class="theme-btn btn-style-one " type="submit" name="submit-form">Submit</button>
                                    </div> 
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Contact Page Section -->



    <br><br><br><br><br>



    <?php include_once("footer.php"); ?>


</div>



<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/mixitup.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="js/map-script.js"></script>
<script src="js/script.js"></script>
<!-- Color Setting -->
<script src="js/color-settings.js"></script>
</body>
</html>