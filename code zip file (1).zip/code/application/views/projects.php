
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Altoona - Interior Creator HTML Template | Contact Us</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">   
<!--Color Switcher Mockup-->
<link href="css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">


    <?php include_once("header.php"); ?>

    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/24.jpg);">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>Projects</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="index.php"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span> Projects </li>
                </ul>
            </div>
        </div>
    </section>

    <section class="team-section">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="team-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="BH201901SVR.php"><img src="images/packages/1.jpeg" alt=""></a></div>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="BH201901SVR.php">BH202101PTM</a> | <a href="#">BH202101PTM</a>  </h3>
                            <span class="designation">1800 sq.ft | Silver Package</span>
                        </div>
                    </div>
                </div>

                <div class="team-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="BH201901SVR.php"><img src="images/packages/2.jpg" alt=""></a></div>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="BH201901SVR.php">BH202101PTM</a> | <a href="#">BH202101PTM</a>  </h3>
                            <span class="designation">1800 sq.ft | Silver Package</span>
                        </div>
                    </div>
                </div>

                <div class="team-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="BH201901SVR.php"><img src="images/packages/3.jpg" alt=""></a></div>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="BH201901SVR.php">BH202101PTM</a> | <a href="#">BH202101PTM</a>  </h3>
                            <span class="designation">1800 sq.ft | Silver Package</span>
                        </div>
                    </div>
                </div>

                <div class="team-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="BH201901SVR.php"><img src="images/packages/1.jpeg" alt=""></a></div>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="BH201901SVR.php">BH202101PTM</a> | <a href="#">BH202101PTM</a>  </h3>
                            <span class="designation">1800 sq.ft | Silver Package</span>
                        </div>
                    </div>
                </div>

                <div class="team-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="BH201901SVR.php"><img src="images/packages/2.jpg" alt=""></a></div>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="BH201901SVR.php">BH202101PTM</a> | <a href="#">BH202101PTM</a>  </h3>
                            <span class="designation">1800 sq.ft | Silver Package</span>
                        </div>
                    </div>
                </div>

                <div class="team-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="BH201901SVR"><img src="images/packages/3.jpg" alt=""></a></div>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="BH201901SVR.php">BH202101PTM</a> | <a href="#">BH202101PTM</a>  </h3>
                            <span class="designation">1800 sq.ft | Silver Package</span>
                        </div>
                    </div>
                </div>

         

           

           

             

             

             

             

            </div>
        </div>
    </section>


 

 

 

  

 

 

    <br><br><br><br><br>



    <?php include_once("footer.php"); ?>


</div>



<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/mixitup.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="js/map-script.js"></script>
<script src="js/script.js"></script>
<!-- Color Setting -->
<script src="js/color-settings.js"></script>
</body>
</html>