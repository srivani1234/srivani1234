<?php //include_once('common/connection.php');?>


<!DOCTYPE html>
<html lang="en">
    <style>
        .body{
            padding:10%;
            text-align:center;
        }
        .container{
            border:2px solid black;
            background-color:#f0f5f5;
            height:300px;
            width:350px;
        }
        .sub{
   padding: top 60px;         
padding:10%;
text-align:center;
        }
    </style>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <titlle>Admin Login</title> -->
</head>
<body>
    <div class="container d-flex justify-content-center">
    <form method="POST" action="<?php echo base_url();?>loginSubmit" id="sub" name="sub" class="sub pt-10" >
    <label>Username:</label>
    <input type="text" name="uname" id="uname" placeholder="Username"/><br><br>
    <label>Password:</label>
    <input type="password" name="pwd" id="pwd" placeholder="Password"/><br><br>
    <input type="submit"  name="submit" value="submit">
</form>
</div>

</body>
</html>