<?php 

$conn =  mysqli_connect('localhost','root','Root@123','test');
if(!$conn){
    echo 'fail';
    //die('error'.mysql_error());
}else{
    return 1;
    //echo  'conncetion established successfully';
}
mysqli_close($conn);

?>

