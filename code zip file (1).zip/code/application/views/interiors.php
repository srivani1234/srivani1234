<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Unico Designs</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">   
<link href="css/color-switcher-design.css" rel="stylesheet">
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
</head>

<body>

<div class="page-wrapper">
  
    <?php include_once("header.php"); ?>

    <section class="banner-section-two" style="background-image: url(images/main-slider/image-7.jpg);">
        <div class="auto-container">
            <div class="row outer-column clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="text-column">
                        <div class="content-box">
                            <h1>We are <b>Unico Designs</b></h1>
                            <div class="text">Quality Homes . Transparent Service .
                                Great Value for Money.</div>
                            <div class="link-box">
                                <a href="#" class="theme-btn btn-style-one">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="form-column">
                        <div class="content-box">
                          <form>
                             <h3>Quick Enquiry</h3>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Name">
  </div>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Phone">
  </div>
  <div class="form-group">
    <input type="name" class="form-control" id="inputAddress" placeholder="Email">
  </div>

  <div class="form-row">
    <div class="form-group col-md-12">
      <select id="inputState" class="form-control">
        <option selected>Select Services</option>
        <option>Construction</option>
        <option>Architecture</option>
        <option>Interior</option>
        <option>Renovations</option>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-12">
      <select id="inputState" class="form-control">
        <option selected>Select your city</option>
        <option>Hyderabad</option>
        <option>Khammam</option>
        <option>Visakhapatnam</option>
      </select>
    </div>
  </div>


  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
       Apply Terms and Condations
      </label>
    </div>
  </div>
  <div class="form-group col-lg-12 col-md-12 col-sm-12">
                                            <button class="theme-btn btn-style-four" type="submit" name="submit-form">Submit Now</button>
                                        </div>  <br>
</form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



  <section class="services-section style-seven" style="background-image: url(images/background/1.jpg);">
        <div class="auto-container">    
            <div class="sec-title text-left">
                <h2>End-to-End Interior Solutions</h2>
            </div>
            <div class="row clearfix">
    <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/1.png">
      <h2>Modular Kitchens</h2>
    </div>
    <div class="flip-box-back">
	
      <img src="images/interiors-icons/1.png">
      <h2>Modular Kitchens</h2>
    </div>
  </div>
</div>
 </div>
 
     <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/2.png">
      <h2>Storage & Wardrobes</h2>
    </div>
    <div class="flip-box-back">

      <img src="images/interiors-icons/2.png">
      <h2>Storage & Wardrobes</h2>
    </div>
  </div>
</div>
 </div>
 
      <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/3.png">
      <h2>Crockery Units</h2>
    </div>
    <div class="flip-box-back">
	
      <img src="images/interiors-icons/3.png">
      <h2>Crockery Units</h2>
    </div>
  </div>
</div>
 </div>
 
       <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/4.png">
      <h2>TV Units</h2>
    </div>
    <div class="flip-box-back">
	
      <img src="images/interiors-icons/4.png">
      <h2>TV Units</h2>
    </div>
  </div>
</div>
 </div>
 
        <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/5.png">
      <h2>Study Tables</h2>
    </div>
    <div class="flip-box-back">
	
      <img src="images/interiors-icons/5.png">
      <h2>Study Tables</h2>
    </div>
  </div>
</div>
 </div>
 
         <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/6.png">
      <h2>False Ceiling</h2>
    </div>
    <div class="flip-box-back">
	
      <img src="images/interiors-icons/6.png">
      <h2>False Ceiling</h2>
    </div>
  </div>
</div>
 </div>
  </div>
  
  <br/>
  
   <div class="row clearfix">
    <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/7.png">
      <h2>Movable Furniture</h2>
    </div>
    <div class="flip-box-back">
	
      <img src="images/interiors-icons/7.png">
      <h2>Movable Furniture</h2>
    </div>
  </div>
</div>
 </div>
 
     <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/8.png">
      <h2>Light</h2>
    </div>
    <div class="flip-box-back">
	
      <img src="images/interiors-icons/8.png">
      <h2>Light</h2>
    </div>
  </div>
</div>
 </div>
 
      <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/9.png">
      <h2>Wall Paint</h2>
    </div>
    <div class="flip-box-back">

      <img src="images/interiors-icons/9.png">
      <h2>Wall Paint</h2>
    </div>
  </div>
</div>
 </div>
 
       <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/10.png">
      <h2>Wall Paper</h2>
    </div>
    <div class="flip-box-back">

      <img src="images/interiors-icons/10.png">
      <h2>Wall Paper</h2>
    </div>
  </div>
</div>
 </div>
 
        <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/11.png">
      <h2>Balcony</h2>
    </div>
    <div class="flip-box-back">

      <img src="images/interiors-icons/11.png">
      <h2>Balcony</h2>
    </div>
  </div>
</div>
 </div>
 
         <div class="col-lg-2 col-md-6 col-sm-12">
    <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front flip-box-front-2">
    <img src="images/interiors-icons/12.png">
      <h2>Bathroom</h2>
    </div>
    <div class="flip-box-back">

      <img src="images/interiors-icons/12.png">
      <h2>Bathroom</h2>
    </div>
  </div>
</div>
 </div>
  </div>
  

        </div>
        <br>
    </section>
	
	
	 <section class="stages">
	 <div class="container">
	 <div class="sec-title text-left">
        <h2>Get Your Favourite Home Now In Only 6 Stages</h2>
    </div>
	  <div class="row">
	<div class="col-lg-1"></div>
	  <div class="col-lg-5">
	    <br/><br/>
	   <h3>Meet Us Online</h3>
	   <ul class="list-style-one">
      <li> Visit Our Website </li>
	  <li> Know about Us </li>
	  <li> Contact Us </li>
	  </ul>
	  </div>
      <div class="col-lg-5">
	  <img src="images/interiors/1.png" alt="">
	</div>
	<div class="col-lg-1"></div>
	</div>
	<hr/>
		  <div class="row">
		  <div class="col-lg-1"></div>
	 <div class="col-lg-5">
	  <img src="images/interiors/2.png" alt="">
	</div>
	  <div class="col-lg-5">
	    <br/><br/>
	   <h3>Talk to Our Designers</h3>
	   <ul class="list-style-one">
      <li> Meet Our Experts </li>
	  <li> Discuss Your Needs </li>
	  <li> Ask For a Free Design Consultation </li>
	  </ul>
	  </div>
     <div class="col-lg-1"></div>
	</div>
	<hr/>
	
		  <div class="row">
		    <div class="col-lg-1"></div>
	  <div class="col-lg-5">
	    <br/><br/>
	   <h3>Finalise Your Design</h3>
	   <ul class="list-style-one">
      <li> Select Your Designs </li>
	  <li> Ask For a Quotation </li>
	  <li> Pay 10% of the Total Amount </li>
	  </ul>
	  </div>
      <div class="col-lg-5">
	  <img src="images/interiors/3.png" alt="">
	</div>
	  <div class="col-lg-1"></div>
	</div>
	
	<hr/>
	  <div class="row">
	    <div class="col-lg-1"></div>
	 <div class="col-lg-5">
	  <img src="images/interiors/4.png" alt="">
	</div>
	  <div class="col-lg-5">
	    <br/><br/>
	   <h3>Seal The Deal</h3>
	   <ul class="list-style-one">
      <li> Pay 40% of the Total for Design Sign-off </li>
	  <li> "50% of the Amount before material dispatch" </li>
	  <li> Work Commences </li>
	  </ul>
	  </div>
       <div class="col-lg-1"></div>
	</div>
	<hr/>
		  <div class="row">
		    <div class="col-lg-1"></div>
	  <div class="col-lg-5">
	    <br/><br/>
	   <h3>Execution</h3>
	   <ul class="list-style-one">
      <li>  Orders get delivered </li>
	  <li> "installation happens" </li>
	  <li> "Post Installation Cleaning" </li>
	  </ul>
	  </div>
      <div class="col-lg-5">
	  <img src="images/interiors/5.png" alt="">
	</div>
	  <div class="col-lg-1"></div>
	</div>
	<hr/>
		  <div class="row">
		    <div class="col-lg-1"></div>
	 <div class="col-lg-5">
	  <img src="images/interiors/6.png" alt="">
	</div>
	  <div class="col-lg-5">
	    <br/><br/>
	   <h3>Move In </h3>
	   <ul class="list-style-one">
      <li> "Final Quality Checks" </li>
	  <li> "You Dream Home is now a Reality" </li>
	  </ul>
	  </div>
       <div class="col-lg-1"></div>
	</div>
	
	
	</div>
	 </section>


 <section class="filters packages">
	 <div class="container">
	 <div class="sec-title text-left">
        <h2>Packages Details</h2>
    </div>
	  <div class="row">
      <div class="col-lg-12">
  <ul class="filters-content">
    <button class="filters__button is-active" data-target="#projects">
   2BHK INTERIORS | Rs.4 Lakhs*
    </button>
    <button class="filters__button" data-target="#skills">
    3BHK Interiors | Rs.5 Lakhs*
    </button>
    <button class="filters__button" data-target="#experience">
   4BHK Interiors | Rs.6 Lakhs*
    </button>
	
  </ul>

  <div>
    <div data-content class="is-active" id="projects">
     <div class="row">
	 <div class="col-lg-5">
	 <ul class="packages-list">
      <li><img src="images/packages/1.png"> <span> Kitchen - Modular</span></li>
	  <li><img src="images/packages/2.png"> <span> Living Room - TV Unit</span> </li>
	  <li><img src="images/packages/3.png"> <span> Living Area - False Ceiling</span> </li>
	  </ul>
    </div>
	
		 <div class="col-lg-5">
	 <ul class="packages-list">
      <li><img src="images/packages/4.png"> <span> Bedroom - 2 wardrobes</span> </li>
	  <li><img src="images/packages/5.png"> <span> Dinning - Crockery Unit</span> </li>
	  <li><img src="images/packages/6.png"> <span> Study unit (or) Shoe rack </span> </li>
	  </ul>
    </div>
</div>
    </div>

    <div data-content id="skills">
     <div class="row">
	 <div class="col-lg-5">
	 <ul class="packages-list">
      <li><img src="images/packages/1.png"> <span> Kitchen - Modular</span></li>
	  <li><img src="images/packages/2.png"> <span> Living Room - TV Unit</span> </li>
	  <li><img src="images/packages/3.png"> <span> Living Area - False Ceiling</span> </li>
	  </ul>
    </div>
	
		 <div class="col-lg-5">
	 <ul class="packages-list">
      <li><img src="images/packages/4.png"> <span> Bedroom - 3 wardrobes</span> </li>
	  <li><img src="images/packages/5.png"> <span> Dinning - Crockery Unit</span> </li>
	  <li><img src="images/packages/6.png"> <span> Study unit (or) Shoe rack </span> </li>
	  </ul>
    </div>
</div>
    </div>
    <div data-content id="experience">
              <div class="row">
	 <div class="col-lg-5">
	 <ul class="packages-list">
      <li><img src="images/packages/1.png"> <span> Kitchen - Modular</span></li>
	  <li><img src="images/packages/2.png"> <span> Living Room - TV Unit</span> </li>
	  <li><img src="images/packages/3.png"> <span> Living Area - False Ceiling</span> </li>
	  </ul>
    </div>
	
		 <div class="col-lg-5">
	 <ul class="packages-list">
      <li><img src="images/packages/4.png"> <span> Bedroom - 4 wardrobes</span> </li>
	  <li><img src="images/packages/5.png"> <span> Dinning - Crockery Unit</span> </li>
	  <li><img src="images/packages/6.png"> <span> Study unit (or) Shoe rack </span> </li>
	  </ul>
    </div>
</div>      
    </div>
  </div>
	  </div>
       </div>
	    </div>
    </section>

   
	
   
   

 


    
	<section class="gallery-section gallery-section-2">
	 <div class="container">
	 <div class="sec-title text-left">
                <h2>The Unico Designs Advantage</h2>
            </div>
	   <div class="row">
       <div class="col-lg-12">
	   <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"> </th>
      <th scope="col">Unico Designs</th>
      <th scope="col">Typical Experience</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">PRICE</th>
      <td>
	  <ul class="list-style-one">
      <li>Best price guarantee</li>
	  <li>Prices per Square feet</li>
	  <li>Transparent and No hidden costs</li>
	  </ul>
	  </td>
      <td>
	   <ul class="list-style-one">
      <li>Comparatively higher prices</li>
	  <li>Lumpsum charges</li>
	  <li>Price hike between first quote and final cost</li>
	  </ul>
	  </td>
    </tr>
	 <tr>
      <th scope="row">QUALITY</th>
      <td>
	  <ul class="list-style-one">
      <li>Branded material</li>
	  <li>140+ Quality checks</li>
	  <li>ISO Quality standards</li>
	  <li>Quality Finishing</li>
	  </ul>
	  </td>
      <td>
	   <ul class="list-style-one">
      <li>Inferior materials used to cut the costs</li>
	  <li>No quality checks</li>
	  <li>Poor standards</li>
	  <li>Poor finishing</li>
	  </ul>
	  </td>
    </tr>
    <tr>
     <th scope="row">SUB-CONTRACTORS</th>
     <td>
	 <ul class="list-style-one">
     <li>NO Sub-Contractors</li>
	 <li>In-house project management, No third-party involvement.</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>YES</li>
	 <li>Mostly outsourced to Sub-contractors</li>
	  </ul>
	  </td>
    </tr>
	
	    <tr>
     <th scope="row">TRANSPARENCY</th>
     <td>
	 <ul class="list-style-one">
     <li>Transparent at every level</li>
	 <li>Pricing, Material specification or documentation and Process.</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>Limited to No transparency</li>
	 <li>NO</li>
	  </ul>
	  </td>
    </tr>
	
	    <tr>
     <th scope="row">CONVINIENCE</th>
     <td>
	 <ul class="list-style-one">
     <li>In-House Team and One-stop solution</li>
	 <li>We take care from Design to handover including Civil, Electrical, Plumbing and False ceiling works.</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>Hassle experience to No support</li>
	 <li>Mostly they outsource.</li>
	  </ul>
	  </td>
    </tr>
	
	    <tr>
     <th scope="row">DESIGN</th>
     <td>
	 <ul class="list-style-one">
     <li>Personalized Interior Designs by Senior Architects</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>Cookie-cutter designs by Junior Architects mostly</li>
	  </ul>
	  </td>
    </tr>
	
	
	    <tr>
     <th scope="row">TIMELINES</th>
     <td>
	 <ul class="list-style-one">
     <li>Standard project can be delivered less than 45days time.</li>
	 <li>On-Time Project Completion with regular updates and Project tracking</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>Delays in project completion and unreliable timelines</li>
	 <li>Poor communication on Project updates/delays</li>
	  </ul>
	  </td>
    </tr>
	
	    <tr>
     <th scope="row">WARRANTY</th>
     <td>
	 <ul class="list-style-one">
     <li>Upto 10-years servicewarranty.</li>
	 <li>We provide after sales customer service</li>
	  </ul>
	  </td>
      <td>
	 <ul class="list-style-one">
     <li>No warranty or Warranty for namesake</li>
	 <li>NO after sales customer service</li>
	  </ul>
	  </td>
    </tr>
	
 
  </tbody>
</table>
	   </div>
      </div>
	 </div>
	</section>
	
	    <section class="clients-section style-four">
        <div class="auto-container">
		<div class="sec-title text-left">
                <h2>Our Brands</h2>
            </div>
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                </ul>
            </div>
        </div>
    </section>


<br><br>

    <?php include_once("footer.php"); ?>


</div>

<!-- Color Palate / Color Switcher -->


<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/script.js"></script>
<!-- Color Setting -->
<script src="js/color-settings.js"></script>

   <script>
const tabs = document.querySelectorAll("[data-target]"),
  tabContents = document.querySelectorAll("[data-content]");

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const target = document.querySelector(tab.dataset.target);

    tabContents.forEach((tc) => {
      tc.classList.remove("is-active");
    });
    target.classList.add("is-active");

    tabs.forEach((t) => {
      t.classList.remove("is-active");
    });
    tab.classList.add("is-active");
  });
});


</script>


</body>
</html>