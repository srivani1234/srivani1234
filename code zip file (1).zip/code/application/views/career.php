

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Altoona - Interior Creator HTML Template | Contact Us</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">   
<!--Color Switcher Mockup-->
<link href="css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">


    <header class="main-header header-style-one">
        <div class="auto-container">
            <div class="main-box clearfix">
                <div class="logo-box">
                    <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
                </div>

                <div class="nav-outer clearfix">
                    <!-- Main Menu -->
                    <nav class="main-menu navbar-expand-md ">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon flaticon-menu"></span>
                            </button>
                        </div>
                        
                        <div class="collapse navbar-collapse clearfix" id="navbarSupportedContent">
                            <ul class="navigation clearfix">
                            <li><a href="construction.php">Construction</a></li>
                            <li><a href="architecture.php">Architecture</a></li>
                            <li><a href="interiors.php">Interior</a></li>
                            <li><a href="renovation.php">Renovations</a></li>
                            <li class="dropdown"><a href="#">More</a>
                            <ul>
                            <li><a href="#"> Packages </a></li>
                            <li><a href="projects.php"> Projects </a></li>
                            <li><a href="about-us.php"> About Us </a></li>
                            <li><a href="#"> Careers</a></li>
                            <li><a href="contact-us.php"> Contact Us</a></li>
                            </ul>
                            </li>
                            </ul>
                        </div>
                    </nav>                      
                    <div class="outer-box clearfix">
                        <div class="header-searchbar">
                            <i class="fa fa-phone"></i> +91 9876543210
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		<div class="sticky-header animated slideInDown">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index.php" title=""><img src="images/logo-small.png" alt="" title=""></a>
                </div>
                <!--Right Col-->
                <div class="pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-collapse show collapse clearfix">
                            <ul class="navigation clearfix">
                            <li><a href="construction.php">Construction</a></li>
                            <li><a href="architecture.php">Architecture</a></li>
                            <li><a href="interiors.php">Interior</a></li>
                            <li><a href="renovation.php">Renovations</a></li>
                             <li class="dropdown"><a href="#">More</a>
                                        <ul>
                                            <li><a href="blog.html"> Packages  </a></li>
                                            <li><a href="blog-detail.html">  Projects  </a></li>
                                            <li><a href="about-us.php">  About Us  </a></li>
                                            <li><a href="blog-detail.html">   Careers  </a></li>
                                            <li><a href="contact-us.php">   Contact Us  </a></li>
                                        </ul>
                                    <div class="dropdown-btn"><span class="fa fa-angle-down"></span></div></li>
                                    <li><a href="tel:+91 9876543210 "><i class="fa fa-phone"></i> +91 9876543210 </a></li>
                                </ul> 
                                
                        </div>
                    </nav>
                    
                </div>
            </div>
        </div>
    </header>
    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/24.jpg);">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>Careers</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="index.php"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span> Careers</li>
                </ul>
            </div>
        </div>
    </section>


    <section class="about-section">
        <div class="auto-container">
            <div class="row">
                <div class="content-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                        <div class="content-box abt-text">
                            <div class="sec-title">
                                <h2 data-animation-child="" class="title-fill" data-animation="title-fill-anim" data-text="About Company">Careers</h2>
                            </div>
                          <p>Unico Designs has been consistently and rapidly touching many milestones and it is our sense of focus which has put us there. We believe in an open culture and value integrity, commitment, teamwork and excellence towards work. As we continue to grow rapidly, professionals passionate about their work and opting to make a career with us today will find more challenging and exciting opportunities to contribute and grow with us. So if you are a smart, talented and enterprising individual and can fit into our organizational culture and value system, headquartered in Hyderabad.</p>
                          <p>We are a team of dynamic and motivated people with a wide range of experience and competence. Our people policies enable competent professionals to realise their career aspirations. Unico Designs has its presence in Chennai, Kochi, Hyderabad, Mangalore and Mysore.</p>
						  <h3>Fun, Open and Creative</h3>
                          <p>Work is so much more enjoyable when it’s at Unico Designs, thanks to the freedom we give our teams in thinking out of the box and coming up with creative ideas! It is this positive ambiance that makes a world of difference in the end product we offer our customers.</p>
						  <h3>Passionate Professionals</h3>
                          <p>If you have been chosen to be a part of the Unico Designs team, you obviously have the potential to become great in your chosen field. We are particular about hiring professionals who are passionate about their work and put together small teams of smart people to learn from each other’s expertise.</p>
                          <h3>Team Vision</h3>
						  <p>Teamwork is the key to maximize productivity. That’s exactly why we share our vision with our team members, making them an integral part of the company’s success and encouraging them to focus meaningful work towards a clear collective goal.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
	
	 <section class="about-section">
        <div class="auto-container">
		<div class="sec-title text-left">
                <h2>Frequently Asked Questions</h2>
            </div>
           <div class="row clearfix">

                <div class="accordion-column col-lg-6 col-md-12 col-sm-12">
                    <div class="outer-column">
                        <div class="inner-column">
                           
                            <ul class="accordion-box">
                                <!--Accordion Block-->
                                <li class="accordion block active-block">
                                    <div class="acc-btn active"><div class="icon-outer"><span class="icon icon_right far fa-arrow-alt-circle-right"></span> <span class="icon icon_down far fa-arrow-alt-circle-down"></span> </div>
                                  CIVIL ENGINEER</div>  

                                    <div class="acc-content" style="display: block;">
                                        <div class="content">
                                            <div class="text"> <strong> Job Title: </strong> Civil Engineer</div>
											<div class="text"> <strong> ob Location:  </strong> Hyderabad </div>
											<div class="text"> <strong> Qualification: </strong> Any Graduates </div>
											<div class="text"> <strong> Experience: </strong> 0 – 2 years </div>
                                        </div>
                                    </div>
                                </li>
                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right far fa-arrow-alt-circle-right"></span> <span class="icon icon_down far fa-arrow-alt-circle-down"></span> </div>
                                  PROJECT MANAGER</div> 
                                    <div class="acc-content" style="">
                                        <div class="content">
                                            <div class="text"> <strong> Job Title: </strong> Project Manager</div>
											<div class="text"> <strong> Job Location:  </strong> Hyderabad </div>
											<div class="text"> <strong> Qualification: </strong> Any Graduates </div>
											<div class="text"> <strong> Experience: </strong> 4 – 6 years </div>
                                        </div>
                                    </div>
                                </li>

                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right far fa-arrow-alt-circle-right"></span> <span class="icon icon_down far fa-arrow-alt-circle-down"></span> </div>
                                    JUNIOR ARCHITECT</div>  
                                    <div class="acc-content current" style="display: none;">
                                        <div class="content">
                                           <div class="text"> <strong> Job Title: </strong> Junior Architect </div>
											<div class="text"> <strong> Job Location:  </strong> Hyderabad </div>
											<div class="text"> <strong> Qualification: </strong> Any Graduates </div>
											<div class="text"> <strong> Experience: </strong> 2 – 4 years </div>
                                        </div>
                                    </div>
                                </li>

                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right far fa-arrow-alt-circle-right"></span> <span class="icon icon_down far fa-arrow-alt-circle-down"></span> </div>
                                  SITE SUPERVISOR</div> 
                                    <div class="acc-content" style="">
                                        <div class="content">
                                           <div class="text"> <strong> Job Title: </strong> Site Supervisor </div>
											<div class="text"> <strong> Job Location:  </strong> Hyderabad </div>
											<div class="text"> <strong> Qualification: </strong> Any Graduates </div>
											<div class="text"> <strong> Experience: </strong> 2 – 6 years </div>
                                        </div>
                                    </div>
                                </li>
                        
                            </ul>
                            <!-- end -->
                        </div>
                    </div>
                </div>
				
				 <div class="accordion-column col-lg-6 col-md-12 col-sm-12">
                    <div class="outer-column">
                        <div class="inner-column">
                           
                            <ul class="accordion-box">
                                <!--Accordion Block-->
                                <li class="accordion block active-block">
                                    <div class="acc-btn active"><div class="icon-outer"><span class="icon icon_right far fa-arrow-alt-circle-right"></span> <span class="icon icon_down far fa-arrow-alt-circle-down"></span> </div>
                                 SALES EXECUTIVE</div>  

                                    <div class="acc-content" style="display: block;">
                                        <div class="content">
                                            <div class="text"> <strong> Job Title: </strong> Sales Executive </div>
											<div class="text"> <strong> ob Location:  </strong> Hyderabad </div>
											<div class="text"> <strong> Qualification: </strong> Any Graduates </div>
											<div class="text"> <strong> Experience: </strong> 0 – 4 years </div>
                                        </div>
                                    </div>
                                </li>
                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right far fa-arrow-alt-circle-right"></span> <span class="icon icon_down far fa-arrow-alt-circle-down"></span> </div>
                                  MARKETING EXECUTIVE</div> 
                                    <div class="acc-content" style="">
                                        <div class="content">
                                            <div class="text"> <strong> Job Title: </strong> Marketing Executive</div>
											<div class="text"> <strong> Job Location:  </strong> Hyderabad </div>
											<div class="text"> <strong> Qualification: </strong> Any Graduates </div>
											<div class="text"> <strong> Experience: </strong> 0 – 4 years (fresher’s can also apply)

 </div>
                                        </div>
                                    </div>
                                </li>

                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right far fa-arrow-alt-circle-right"></span> <span class="icon icon_down far fa-arrow-alt-circle-down"></span> </div>
                                    ACCOUNTANT</div>  
                                    <div class="acc-content current" style="display: none;">
                                        <div class="content">
                                           <div class="text"> <strong> Job Title: </strong> Accountant </div>
											<div class="text"> <strong> Job Location:  </strong> Hyderabad </div>
											<div class="text"> <strong> Qualification: </strong> Any Graduates </div>
											<div class="text"> <strong> Experience: </strong> 2 – 4 years </div>
                                        </div>
                                    </div>
                                </li>

                                <!--Accordion Block-->
                                <li class="accordion block">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon_right far fa-arrow-alt-circle-right"></span> <span class="icon icon_down far fa-arrow-alt-circle-down"></span> </div>
                                  SITE SUPERVISOR</div> 
                                    <div class="acc-content" style="">
                                        <div class="content">
                                           <div class="text"> <strong> Job Title: </strong> Site Supervisor </div>
											<div class="text"> <strong> Job Location:  </strong> Hyderabad </div>
											<div class="text"> <strong> Qualification: </strong> Any Graduates </div>
											<div class="text"> <strong> Experience: </strong> 2 – 6 years </div>
                                        </div>
                                    </div>
                                </li>
                        
                            </ul>
                            <!-- end -->
                        </div>
                    </div>
                </div>
				
				
            </div>
        </div>
    </section>

   
   

    
   

    

    <br><br><br><br><br>



    <footer class="main-footer style-three">
    <div class="auto-container">
        <div class="widgets-section">
            <div class="row">
                <!--Big Column-->
                <div class="big-column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                    <div class="row">
                        <!--Footer Column-->
                        <div class="footer-column col-xl-7 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget about-widget">
                                <h2 class="widget-title">About Us</h2>
                                <div class="widget-content">
                                    <div class="text">Lorem ipsum is simply free text dolor sit amet, consecte tur notted adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqualonm.</div>
                                 
                                </div>
                            </div>
                        </div>
                        
                        <!--Footer Column-->
                        <div class="footer-column col-xl-5 col-lg-6 col-md-6 col-sm-12">
                             <div class="footer-widget links-widget">
                                <h2 class="widget-title">Quick Links</h2>
                                <div class="widget-content">
                                    <ul class="list">
                                        <li><a href="index.php"> Home </a></li>
                                        <li><a href="about-us.php"> About Us </a></li>
                                        <li><a href="construction.php"> Construction </a></li>
                                        <li><a href="architecture.php"> Architecture </a></li>
                                        <li><a href="projects.php"> Projects </a></li>
                                        <li><a href="contact-us.php"> Contact Us </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>         
                    </div>
                </div>
                
                <!--Big Column-->
                <div class="big-column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                    <div class="row clearfix">
                        <!--Footer Column-->
                        <div class="footer-column col-xl-7 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget gallery-widget">
                                <h2 class="widget-title">Recent Projects</h2>
                                <div class="widget-content">
                                    <div class="outer clearfix">
                                        <figure class="image">
                                            <a href="images/resource/work-thumb-1.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-1.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-2.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-2.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-3.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-3.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-4.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-4.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-5.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-5.jpg" alt=""></a>
                                        </figure>

                                        <figure class="image">
                                            <a href="images/resource/work-thumb-6.jpg" class="lightbox-image" title="Image Title Here"><img src="images/resource/work-thumb-6.jpg" alt=""></a>
                                        </figure>
                                    </div>
                                </div>       
                            </div>
                        </div>
                        <div class="footer-column col-xl-5 col-lg-6 col-md-6 col-sm-12">
                             <div class="footer-widget links-widget">
                                <h2 class="widget-title">Contact Us</h2>
                                <div class="widget-content">
                                    <ul class="list-address">
                                        <li><i class="fas fa-map-marker-alt"></i>Hyderabad, Telangana, India.</li>
                                        <li><i class="fas fa-phone-volume"></i><a href="tel:+91 9876543210">+91 9876543210</a></li>
                                        <li><i class="fas fa-envelope"></i><a href="mailto:info@unicodesigns.com">info@unicodesigns.com</a></li>
                                    </ul>
                                    <div class="social-links">
                                        <ul class="social-icon-two">
                                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                                           
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--Footer Bottom-->
    <div class="footer-bottom style-two">
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="inner-container clearfix">
                        <div class="copyright-text">
                            <p> © 2022 Unico Designs. All Right Reserved.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="inner-container clearfix">
                        <div class="copyright-text powered">
                            <p> Powered by <a href="https://royalitpark.com/" target="_blank"> Royal IT Park</a> </p>
                        </div>
                    </div>
                   
                </div>
            </div>
          
        </div>
    </div>
</footer>

</div>



<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/mixitup.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="js/map-script.js"></script>
<script src="js/script.js"></script>
<!-- Color Setting -->
<script src="js/color-settings.js"></script>
</body>
</html>