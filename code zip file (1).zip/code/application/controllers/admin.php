<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller{
       public function __construct(){
        parent::__construct();
       
        $this->load->library('session');
        $this->load->model('login_model');

       }
       public function login(){ 
       // echo 'hello';
        $this->load->view('adminlogin');
       }

       public function loginSubmit(){      
              //echo 'success';
		 $uname=$_POST['uname'];
	         $pwd=$_POST['pwd'];
	       $_SESSION['uname']=$uname;
               $_SESSION['pwd']=$pwd;
              $rr=$this->login_model->login($uname,$pwd);
             // print_r($rr);
              //exit;
             if($rr=='1'){
                  echo '1';
                  redirect(base_url().'cms');
     //  return 1;
                 }else{
                    echo 'ff';
                     return 0;
}
       }
public function cms(){
      // echo 'dash';
       if(isset($_SESSION['uname'])){
              $this->load->view('cmsdaashboard');

       }else{
              echo 'dashboard';
       }
}
public function addconstruction(){
       $this->load->view('addconstruction');
}

       }

//}
?>