<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	 public function __construct() {
		 parent::__construct();
		 $this->load->helper('url');
		 $this->load->model('welcome_model');
		 $this->load->model('login_model');
		 
		 $this->load->library('session');
	 }
	
	// public function adm(){
	// 	$this->load->view('adminlogin');
	// }
	
	 public function text()

	{
		//echo "hello";
		$this->load->view('welcome_message');
	}
	public function index(){

		//echo 'kk';
		$this->load->view('header');
		$this->load->view('index');
		$this->load->view('footer');

	}
	public function construction(){

		//echo 'kk';
		 $this->load->view('header');
		$this->load->view('construction');
		 $this->load->view('footer');

	}
	public function architecture(){

		//echo 'kk';
		 $this->load->view('header');
		$this->load->view('architecture');
		$this->load->view('footer');

	}
	public function interiors(){
		// $this->load->view('header');
		$this->load->view('interiors');
		// $this->load->view('footer');

	}
	public function renovation(){
		// $this->load->view('header');
		$this->load->view('renovation');
		// $this->load->view('footer');

	}
	public function packages(){
		// $this->load->view('header');
		$this->load->view('packages');
		// $this->load->view('footer');

	}
	public function projects(){
		// $this->load->view('header');
		$this->load->view('projects');
		// $this->load->view('footer');

	}
	public function aboutus(){
		// $this->load->view('header');
		$this->load->view('about-us');
		// $this->load->view('footer');

	}

	public function career(){
		// $this->load->view('header');
		$this->load->view('career');
		// $this->load->view('footer');

	}

	public function contactus(){
		// $this->load->view('header');
		$this->load->view('contact-us');
		// $this->load->view('footer');

	}
}

