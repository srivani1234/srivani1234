<?php 
class welcome_model extends CI_MOdel{
    public function __construct(){

        parent::__construct();
        $this->load->database('default',TRUE);
        $this->load->library('session');

    }
    
}

?>