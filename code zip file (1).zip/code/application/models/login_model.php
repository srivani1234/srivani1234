<?PHP

Defined('BASEPATH') OR exit('No direct script access allowed');

class login_model extends CI_Model {

  public function  __construct() {

    parent::__construct();
    $this->load->helper('url');

    $this->db =$this->load->database('default',true);
  }
  public function login($uname,$pwd){
    $sql="insert into admin values('','$uname','$pwd')";
    $rr=$this->db->query($sql);
    if($rr){
      return $rr;
    }else{
      return '0';
    }
  }

}


?>